<?php

echo '<?xml version="1.0" encoding="UTF-8"?><?xml-stylesheet type="text/xsl" href="' . site_url() . '/application/views/sitemap.xsl"?>';

if ( ! route( 'sitemap-index' ) ) {
  echo '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    if ( route( 'sitemap-misc' ) ) {
      echo '<url>' . "\n";
      echo '<loc>' . site_url() . '</loc>' . "\n";
      echo '<lastmod>' . date( 'c', time() ) . '</lastmod>' . "\n";
      echo '<changefreq>daily</changefreq>' . "\n";
      echo '<priority>0.7</priority>' . "\n";
      echo '</url>' . "\n";
    }

    if ( isset( $mc['sitemap'] ) ) {
      foreach ( $mc['sitemap'] as $sitemap ) {
        echo '<url>' . "\n";
        echo '<loc>' . $sitemap . '</loc>' . "\n";
        echo '<lastmod>' . date( 'c', time() ) . '</lastmod>' . "\n";
        echo '<changefreq>daily</changefreq>' . "\n";
        echo '<priority>0.7</priority>' . "\n";
        echo '</url>' . "\n";
      }
    }
  echo '</urlset>';
}

else {
  echo '<sitemapindex xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/siteindex.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

  if ( isset( $mc['sitemap'] ) ) {
    foreach ( $mc['sitemap'] as $sitemaps ) {
      foreach ( $sitemaps as $sitemap ) {
        echo '<sitemap>';
        echo '<loc>' . $sitemap . '</loc>';
        echo '<lastmod>' . date( 'c', time() ) . '</lastmod>';
        echo '</sitemap>';
      }
    }
  }

  echo '</sitemapindex>';
}
