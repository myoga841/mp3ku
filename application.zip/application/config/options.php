<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

return [

  /**
   * Informasi website
   */

  'site_name' => 'Master Mp3',
  'site_tagline' => 'Mp3 AGC Script',

  /**
   * Minify HTML
   * Ubah menjadi 'false' jika tidak ingin me-minify html
   * Disarakankan tetap 'true' agar load website menjadi lebih cepat
   */

  'minify' => true,

  /**
   * Gunakan nama direktori tema untuk menggunakan tema
   */

  'theme' => 'default',

  /**
   * Pengaturan YouTube
   */

  // Pisahkan dengan koma untuk banyak API
  // Contoh: 'youtube_api_keys' => 'AIzaSyDTHCLB62MLZusiLkXppEC-nl2yjfbkvNM,api2,api3,api4,api5'
  'youtube_api_keys' => 'AIzaSyDTHCLB62MLZusiLkXppEC-nl2yjfbkvNM',

  // Referensi kode negara: http://www.1728.org/countries.htm
  'youtube_country_code' => 'US',

  // Isi 'api' jika ingin memprioritaskan hasil pencarian YouTube menggunakan API
  'youtube_search_priority' => 'non_api',

  'youtube_search_limit' => 20,

  // Isi 'api' jika ingin memprioritaskan hasil detail video YouTube menggunakan API
  'youtube_download_priority' => 'non_api',

  // Ubah menjadi 'false' jika tidak ingin menampilkan video terkait di halaman download
  'youtube_download_related' => true,

  /**
   * SEO
   */

  'site_title_position' => '%site_title% %sep% %site_name%',
  'site_title_separator' => '&#8211;',

  // Tag yang bisa digunakan: %site_tagline%
  'index_title' => '%site_tagline%',

  // Tag yang bisa digunakan: %name%
  'genre_title' => '%name% Songs',

  // Tag yang bisa digunakan: %query%, %size%
  'search_title' => '(%size%) %query%',

  // Tag yang bisa digunakan: %title%, %size%, %duration%
  'download_title' => '(%size%) %title%',

  // Tag yang bisa digunakan: %name%
  'page_title' => '%name%',

  '404_title' => '404',

  'index_meta_image_url' => '%site_url%/assets/images/index.jpg',

  // Tag yang bisa digunakan: %site_name%, %site_tagline%, %domain%
  'index_meta_description' => '%site_name% | %site_tagline% | %domain%',

  // Tag yang bisa digunakan: %name%, %site_name%, %domain%
  'genre_meta_description' => '%name% | %site_name% | %domain%',

  // Tag yang bisa digunakan: %query%, %size%, %site_name%, %domain%
  'search_meta_description' => '%query% | %size% | %site_name% | %domain%',

  // Tag yang bisa digunakan: %title%, %size%, %duration%, %channel%, %date%, %site_name%, %domain%
  'download_meta_description' => '%title% | %size% | %duration% | %channel% | %date% | %site_name% | %domain%',

  'index_meta_robots' => 'index,follow',
  'genre_meta_robots' => 'index,follow',
  'search_meta_robots' => 'index,follow',
  'download_meta_robots' => 'noindex,follow',
  'page_meta_robots' => 'noindex,follow',

  /**
   * Pemalink
   */

  // Tag yang harus ada: %name%
  'genre_permalink' => 'genre/%name%',

  // Tag yang harus ada: %query%
  'search_permalink' => '%query%',

  // Tag yang harus ada: %title%, %id%
  'download_permalink' => 'download/%title%/%id%',

  // Tag yang harus ada: %name%
  'page_permalink' => 'page/%name%',

  'sitemap_index_permalink' => 'sitemap.xml',
  'sitemap_misc_permalink' => 'sitemap-misc.xml',

  // Tag yang harus ada: %type%
  'sitemap_terms_permalink' => 'sitemap-terms-%type%.xml',

  // Tag yang harus ada: %file%, %page%
  'sitemap_keywords_permalink' => 'sitemap-keywords-%file%-%page%.xml',

  /**
   * Lainnya
   */

  // Ubah menjadi 'false' jika tidak ingin mengaktifkan cache
  'use_cache' => true,

  // Isi dalam detik. 300 berarti cache akan disimpan selama 5 menit
  'cache_expiration_time' => 300,

  'save_stt' => true,
  'save_recent_search' => true,
  'max_stt_to_save' => 5000,
  'max_recent_search_to_save' => 5000,

  // Maksimal 50000 baris untuk alasan performance
  'sitemap_limit_per_page' => 50000,

  'use_default_proxies' => true,
  'use_default_bad_words' => true,
  'use_default_keywords' => true,
  'use_default_data' => true,
  'use_default_pages' => true,
  'use_default_cache' => true,

  // Bisa digunakan untuk peletakan kode tracking (histats,analytics,dll)
  'header_code' => 'file:%default_site_dir%/config/header.txt',
  'footer_code' => 'file:%default_site_dir%/config/footer.txt'
];
