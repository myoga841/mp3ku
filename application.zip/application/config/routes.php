<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

return [
  [
    'name'          => 'index',
    'uri'           => '/',
    'controllers'   => [ 'main', 'index' ],
    'template'      => '%theme%/index'
  ],
  [
    'name'          => 'genre',
    'uri'           => [ '%name%' => CLEAN_VAR ],
    'controllers'   => [ 'main', 'genre' ],
    'template'      => '%theme%/genre'
  ],
  [
    'name'          => 'search',
    'uri'           => [ '%query%' => CLEAN_VAR ],
    'controllers'   => [ 'main', 'search' ],
    'template'      => '%theme%/search'
  ],
  [
    'name'          => 'download',
    'uri'           => [ '%title%' => CLEAN_VAR, '%id%' => '([a-z-A-Z-0-9]+)' ],
    'controllers'   => [ 'main', 'download' ],
    'template'      => '%theme%/download'
  ],
  [
    'name'          => 'page',
    'uri'           => [ '%name%' => CLEAN_VAR ],
    'controllers'   => [ 'main', 'page' ],
    'template'      => '%theme%/page'
  ],
  [
    'name'          => 'sitemap-index',
    'uri'           => 'sitemap.xml',
    'controllers'   => [ 'main', 'sitemap' ],
    'template'      => '%views%/sitemap'
  ],
  [
    'name'          => 'sitemap-misc',
    'uri'           => 'sitemap-misc.xml',
    'controllers'   => [ 'main', 'sitemap' ],
    'template'      => '%views%/sitemap'
  ],
  [
    'name'          => 'sitemap-terms',
    'uri'           => [ '%type%' => '([0-9]+)' ],
    'controllers'   => [ 'main', 'sitemap' ],
    'template'      => '%views%/sitemap'
  ],
  [
    'name'          => 'sitemap-keywords',
    'uri'           => [ '%file%' => '([0-9]+)', '%page%' => '([0-9]+)' ],
    'controllers'   => [ 'main', 'sitemap' ],
    'template'      => '%views%/sitemap'
  ]
];
