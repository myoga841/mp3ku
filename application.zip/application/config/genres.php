<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

return [
  [
    'id'    => '20',
    'slug'  => 'alternative',
    'name'  => 'Alternative'
  ],
  [
    'id'    => '2',
    'slug'  => 'blues',
    'name'  => 'Blues'
  ],
  [
    'id'    => '4',
    'slug'  => 'children',
    'name'  => 'Children'
  ],
  [
    'id'    => '5',
    'slug'  => 'classical',
    'name'  => 'Classical'
  ],
  [
    'id'    => '6',
    'slug'  => 'country',
    'name'  => 'Country'
  ],
  [
    'id'    => '17',
    'slug'  => 'dance',
    'name'  => 'Dance'
  ],
  [
    'id'    => '7',
    'slug'  => 'electronic',
    'name'  => 'Electronic'
  ],
  [
    'id'    => '18',
    'slug'  => 'hip-hop-rap',
    'name'  => 'Hip-Hop/Rap'
  ],
  [
    'id'    => '11',
    'slug'  => 'jazz',
    'name'  => 'Jazz'
  ],
  [
    'id'    => '14',
    'slug'  => 'pop',
    'name'  => 'Pop'
  ],
  [
    'id'    => '15',
    'slug'  => 'r-b-soul',
    'name'  => 'R&amp;B/Soul'
  ],
  [
    'id'    => '24',
    'slug'  => 'reggae',
    'name'  => 'Reggae'
  ],
  [
    'id'    => '21',
    'slug'  => 'rock',
    'name'  => 'Rock'
  ],
  [
    'id'    => '19',
    'slug'  => 'world',
    'name'  => 'World'
  ]
];
