<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

if ( $route['template'] ) {
  if ( isset( $route['custom_template'] ) )
    $route['template'] = $route['custom_template'];

  if ( defined( 'THEME' ) )
    $__template_dir['%theme%'] = THEME;

  $__template_dir['%views%'] = APP . '/views';

  $__template_path = strtr( $route['template'], $__template_dir ) . '.php';;
  $__template_file = basename( $__template_path );
  $__template_dir = strtr( dirname( $__template_path ), [ BASE => '' ] );

  if ( file_exists( $__template_path ) ) {
    if ( option( 'minify' ) ) {
      require_once APP . '/libraries/minifier.php';

      ob_start();
      include_once $__template_path;
      $__output = ob_get_clean();

      echo minify_html( $__output );

      unset( $__output );
    } else {
      include_once $__template_path;
    }

    unset( $__template_dir, $__template_path, $__template_file );
  } else {
    error( '<p>This template file is not found:</p><p><strong>' . $__template_dir . '/' . $__template_file . '</strong></p>' );
  }
}
