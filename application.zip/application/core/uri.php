<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

function __uri_path( $uri ) {
  return parse_url( $uri, PHP_URL_PATH );
}

$__path = ( PATH === '' ) ? '/' : PATH;
$__request_uri = substr( $_SERVER['REQUEST_URI'], 1 );
$__request_uri_parts = array_map( '__uri_path', explode( '/', $__request_uri ) );
$__clean_request_uri_parts = clean_array( $__request_uri_parts );
$__parse_uri = parse_url( '/' . ltrim( $_SERVER['REQUEST_URI'], '/' ) );
$__clean_path = strtr( $__parse_uri['path'], [ PATH => '' ] );

if ( $__path === '/' ) {
  $uri['path'] = ( $__parse_uri['path'] !== '/' ) ? ltrim( $__parse_uri['path'], '/' ) : '/';
} else {
  $uri['path'] = ( $__clean_path !== '/' ) ? str_replace( PATH . '/', '', $__parse_uri['path'] ) : '/';
}

$uri['query'] = ( isset( $__parse_uri['query'] ) ) ? $__parse_uri['query'] : '';

if ( $uri['path'] != '/' ) {
  $__uri_path_parts = explode( '/', $uri['path'] );
  $__filter_uri_path = array_filter( $__uri_path_parts, 'strlen' );

  if ( count( $__request_uri_parts ) > count( $__clean_request_uri_parts ) ) {
    $__redirect = implode( $__filter_uri_path, '/' );
    $__redirect.= ( ! empty( $uri['query'] ) ) ? '?' . rtrim( $uri['query'], '/' ) : '';

    redirect( site_url() . '/' . $__redirect, [ 'permanent' => true ] );
  }

  else {
    $__uri_contain_slashes = $__uri_path_parts;
    $__uri_has_slashes = false;

    if ( count( $__uri_contain_slashes ) > count( $__filter_uri_path ) && count( $__uri_contain_slashes ) > ( count( $__filter_uri_path ) + 1 ) ) {
      $__uri_has_slashes = true;
    } elseif ( count( $__uri_contain_slashes ) > count( $__filter_uri_path ) ) {
      $__uri_has_slashes = true;
    }

    if ( uri_has_extension( $uri['path'] ) )
      $__uri_has_slashes = false;

    if ( $__uri_has_slashes ) {
      $__redirect = implode( array_filter( $__clean_request_uri_parts ), '/' );
      $__redirect.= ( ! empty( $uri['query'] ) ) ? '?' . rtrim( $uri['query'] ) : '';

      redirect( site_url() . '/' . $__redirect, [ 'permanent' => true ] );
    }

    unset( $__uri_contain_slashes, $__uri_has_slashes );
  }

  unset( $__uri_path_parts, $__filter_uri_path );
}

unset( $__path, $__request_uri, $__request_uri_parts, $__clean_request_uri_parts, $__parse_uri, $__clean_path );
