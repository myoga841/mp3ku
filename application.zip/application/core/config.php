<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

$__default_options_config_file = APP . '/config/options.php';
$__default_site_options_config_file = DEFAULT_SITE . '/config/options.php';
$__site_options_config_file = SITE . '/config/options.php';

$config['options'] = [];

if ( file_exists( $__default_options_config_file ) )
  $config['options'] = require_once $__default_options_config_file;

if ( file_exists( $__default_site_options_config_file ) ) {
  $__default_site_options = require_once $__default_site_options_config_file;
  $config['options'] = array_merge( $config['options'], $__default_site_options );
  unset( $__default_site_options );
}

if ( file_exists( $__site_options_config_file ) ) {
  $__site_options = require_once $__site_options_config_file;
  $config['options'] = array_merge( $config['options'], $__site_options );
  unset( $__site_options );
}

unset( $__default_options_config_file, $__default_site_options_config_file, $__site_options_config_file );

/*----------------------------------------------------------------------------*/

$__default_routes_config_file = APP . '/config/routes.php';
$__default_site_routes_config_file = DEFAULT_SITE . '/config/routes.php';
$__site_routes_config_file = SITE . '/config/routes.php';

$config['routes'] = [];

if ( file_exists( $__default_routes_config_file ) )
  $config['routes'] = require_once $__default_routes_config_file;

if ( file_exists( $__default_site_routes_config_file ) ) {
  $__default_site_routes = require_once $__default_site_routes_config_file;
  $config['routes'] = array_merge( $config['routes'], $__default_site_routes );
  unset( $__default_site_routes );
}

if ( file_exists( $__site_routes_config_file ) ) {
  $__site_routes = require_once $__site_routes_config_file;
  $config['routes'] = array_merge( $config['routes'], $__site_routes );
  unset( $__site_routes );
}

unset( $__default_routes_config_file, $__default_site_routes_config_file, $__site_routes_config_file );

/*----------------------------------------------------------------------------*/

$config['theme_options'] = [];

if ( isset( $config['options']['theme'] ) && is_dir( BASE . '/themes/' . $config['options']['theme'] ) ) {
  define( 'THEME', BASE . '/themes/' . $config['options']['theme'] );

  $__default_theme_options_config_file = APP . '/config/themes/' . $config['options']['theme'] . '/options.php';
  $__default_site_theme_options_config_file = DEFAULT_SITE . '/config/themes/' . $config['options']['theme'] . '/options.php';
  $__site_theme_options_config_file = SITE . '/config/themes/' . $config['options']['theme'] . '/options.php';

  if ( file_exists( $__default_theme_options_config_file ) )
    $config['theme_options'] = require_once $__default_theme_options_config_file;

  if ( file_exists( $__default_site_theme_options_config_file ) ) {
    $__default_site_theme_options = require_once $__default_site_theme_options_config_file;
    $config['theme_options'] = array_merge( $config['theme_options'], $__default_site_theme_options );
    unset( $__default_site_theme_options );
  }

  if ( file_exists( $__site_theme_options_config_file ) ) {
    $__site_theme_options = require_once $__site_theme_options_config_file;
    $config['theme_options'] = array_merge( $config['theme_options'], $__site_theme_options );
    unset( $__site_theme_options );
  }

  unset( $__default_theme_options_config_file, $__default_site_theme_options_config_file, $__site_theme_options_config_file );

  if ( file_exists( THEME . '/functions.php' ) )
    require_once THEME . '/functions.php';
}

/*----------------------------------------------------------------------------*/

$config['genres'] = [];

$__genres_config_file = APP . '/config/genres.php';

if ( file_exists( $__genres_config_file ) )
  $config['genres'] = require_once $__genres_config_file;

/*----------------------------------------------------------------------------*/

$config['menus'] = [];

$__default_site_menus_config_file = DEFAULT_SITE . '/config/menus.php';
$__site_menus_config_file = SITE . '/config/menus.php';

if ( file_exists( $__default_site_menus_config_file ) )
  $config['menus'] = require_once $__default_site_menus_config_file;

if ( file_exists( $__site_menus_config_file ) ) {
  $__site_menus = require_once $__site_menus_config_file;
  $config['menus'] = array_merge( $config['menus'], $__site_menus );
  unset( $__site_menus );
}

unset( $__default_site_menus_config_file, $__site_menus_config_file );
