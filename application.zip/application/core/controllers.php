<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

if ( $route['controllers'] && is_array( $route['controllers'] ) ) {
  foreach ( $route['controllers'] as $__controller ) {
    $__controller_file = APP . '/controllers/' . $__controller . '.php';

    if ( file_exists( $__controller_file ) )
      require_once $__controller_file;

    unset( $__controller, $__controller_file );
  }
}

/*----------------------------------------------------------------------------*/

if ( $error404 ) {
  set_404();

  foreach ( $route['controllers'] as $__controller ) {
    $__controller_file = APP . '/controllers/' . $__controller . '.php';

    if ( file_exists( $__controller_file ) )
      require_once $__controller_file;

    unset( $__controller, $__controller_file );
  }
}
