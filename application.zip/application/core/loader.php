<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

define( 'CLEAN_VAR', '([^/~!\$&*\(\)=|;\'\.]+)', true );

/*----------------------------------------------------------------------------*/

$functions_files = glob( APP . '/functions/*' );

if ( $functions_files )
  foreach ( $functions_files as $functions_file )
    require_once $functions_file;

/*----------------------------------------------------------------------------*/

if ( file_exists( APP . '/libraries/vendor/autoload.php' ) )
  require_once APP . '/libraries/vendor/autoload.php';

/*----------------------------------------------------------------------------*/

require_once APP . '/core/config.php';
require_once APP . '/core/uri.php';
require_once APP . '/core/router.php';
require_once APP . '/core/controllers.php';
require_once APP . '/core/template.php';
