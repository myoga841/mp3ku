<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

$error404 = true;

/*----------------------------------------------------------------------------*/

foreach ( $config['routes'] as $__route_position => $__route ) {
  if ( isset( $config['options'][$__route['name'] . '_permalink'] ) ) {
    $__route_uri = $config['options'][$__route['name'] . '_permalink'];
    $__route_uri_parts = explode( '/', $__route_uri );

    if ( count( $__route_uri_parts ) === 1 ) {
      $__special_route_position = $__route_position;
      break;
    }

    unset( $__route_uri, $__route_uri_parts );
  }

  unset( $__route_position, $__route );
}

if ( isset( $__special_route_position ) ) {
  $__special_route = $config['routes'][$__special_route_position];

  unset( $config['routes'][$__special_route_position] );

  $config['routes'] = array_values( $config['routes'] );
  $config['routes'][] = $__special_route;
}

/*----------------------------------------------------------------------------*/

foreach ( $config['routes'] as $route ) {
  $__route_uri = $route['uri'];
  $__safe_route_name = strtr( $route['name'], [ '-' => '_' ] );

  if ( isset( $config['options'][$__safe_route_name . '_permalink'] ) ) {
    if ( is_array( $route['uri'] ) ) {
      $route['uri'] = strtr( $config['options'][$__safe_route_name . '_permalink'], $route['uri'] );
    } else {
      $route['uri'] = $config['options'][$__safe_route_name . '_permalink'];
    }
  } else {
    if ( is_array( $route['uri'] ) )
      $route['uri'] = implode( array_values( $route['uri'] ), '/' );
  }

  $__pattern = '/^' . str_replace( '/', '\/', $route['uri'] ) . '$/';

  if ( preg_match( $__pattern, $uri['path'], $__vars ) ) {
    array_shift( $__vars );

    if ( is_array( $__route_uri ) ) {
      $__var_tags = array_keys( $__route_uri );

      foreach ( $__var_tags as $__var_tag_key => $__var_tag_value ) {
        $__var_tag_value = strtr( $__var_tag_value, [ '%' => '' ] );
        $__route_vars[$__var_tag_value] = urldecode( $__vars[$__var_tag_key] );

        unset( $__var_tag_key, $__var_tag_value );
      }

      unset( $__var_tags );
    } else {
      $__route_vars = $__vars;
    }

    $route['vars']        = ( isset( $__route_vars ) ) ? $__route_vars : [];
    $route['controllers'] = ( isset( $route['controllers'] ) && $route['controllers'] ) ? $route['controllers'] : false;
    $route['template']    = ( isset( $route['template'] ) && $route['template'] ) ? $route['template'] : false;

    unset( $route['uri'] );

    $error404 = false;

    unset( $__route_vars, $__route_uri, $__safe_route_name );

    break;
  }

  unset( $__pattern, $__route_uri, $__safe_route_name );
}

if ( $error404 )
  set_404();
