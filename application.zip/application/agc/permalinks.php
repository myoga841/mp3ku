<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

function search_permalink( $query ) {
  $uri = strtr( option( 'search_permalink', '%query%' ), [ '%query%' => clean_uri( $query ) ] );
  return site_url() . '/' . $uri;
}

function download_permalink( $title, $id ) {
  $title = clean_uri( $title );
  $id = base64__encode( $id );
  $uri = strtr( option( 'download_permalink', '%title%/%id%' ), [ '%title%' => $title, '%id%' => $id ] );
  return site_url() . '/' . $uri;
}

function page_permalink( $name ) {
  $uri = strtr( option( 'page_permalink', 'page/%name%' ), [ '%name%' => $name ] );
  return site_url() . '/' . $uri;
}

function sitemap_misc_permalink() {
  return site_url() . '/' . option( 'sitemap_misc_permalink', 'sitemap-misc.xml' );
}

function sitemap_terms_permalink( $type ) {
  $uri = strtr( option( 'sitemap_terms_permalink', 'sitemap-terms-%type%.xml' ), [ '%type%' => $type ] );
  return site_url() . '/' . $uri;
}

function sitemap_keywords_permalink( $file, $page ) {
  $uri = strtr( option( 'sitemap_keywords_permalink', 'sitemap-%file%-%page%.xml' ), [ '%file%' => $file, '%page%' => $page ] );
  return site_url() . '/' . $uri;
}
