<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

use Phpfastcache\CacheManager;
use Phpfastcache\Config\ConfigurationOption;

CacheManager::setDefaultConfig(
  new ConfigurationOption( [
    'path' => BASE . '/cache'
  ] )
);

$cache_instance = CacheManager::getInstance( 'files' );

/*----------------------------------------------------------------------------*/

function hot_tracks( $limit = 12 ) {
  return itunes( 'top-songs', $limit );
}

function new_releases( $limit = 12 ) {
  return itunes( 'recent-releases', $limit );
}

function itunes( $name = 'top-songs', $limit = 10 ) {
  global $cache_instance;

  $data = [];
  $url = 'https://rss.itunes.apple.com/api/v1/us/itunes-music/' . $name . '/all/' . $limit . '/non-explicit.json';
  $cache = $cache_instance->getItem( md5( $url ) );

  if ( ! is_null( $cache->get() ) && option( 'use_cache', true) ) {
    $data = json_decode( $cache->get(), true );
  } else {
    $curl = curl( $url );
    if ( $curl['info']['http_code'] == 200 ) {
      $response = json_decode( $curl['data'], true );
      if ( isset( $response['feed']['results'] ) ) {
        foreach ( $response['feed']['results'] as $result ) {
          $data[] = [
            'title' => $result['name'],
            'artist' => $result['artistName'],
            'full_title' => $result['artistName'] . ' - ' . $result['name'],
            'image' => str_replace( '200x200bb', '100x100bb', $result['artworkUrl100'] )
          ];
        }

        if ( option( 'use_cache', true ) && $data ) {
          $cache->set( json_encode( $data ) )->expiresAfter( option( 'cache_expiration_time', 300 ) );
          $cache_instance->save( $cache );
        }
      }
    }
  }

  return $data;
}

function itunes_genre( $id, $limit = 10, $type = 'topsongs' ) {
  global $cache_instance;

  $data = [];
  $url = 'https://itunes.apple.com/us/rss/' . $type . '/limit=' . $limit . '/genre=' . $id . '/json';
  $cache = $cache_instance->getItem( md5( $url ) );

  if ( ! is_null( $cache->get() ) && option( 'use_cache', true) ) {
    $data = json_decode( $cache->get(), true );
  } else {
    $curl = curl( $url );

    if ( $curl['info']['http_code'] == 200 ) {
      $response = json_decode( $curl['data'], true );
      if ( isset( $response['feed']['entry'] ) ) {
        foreach ( $response['feed']['entry'] as $result ) {
          $item = [];

          $item['title'] = $result['im:name']['label'];
          $item['artist'] = $result['im:artist']['label'];
          $item['full_title'] = $result['title']['label'];
          $item['image'] = str_replace( '55x55bb', '100x100bb', $result['im:image'][0]['label'] );

          if ( $item )
            $data[] = $item;
        }

        if ( option( 'use_cache', true ) && $data ) {
          $cache->set( json_encode( $data ) )->expiresAfter( option( 'cache_expiration_time', 300 ) );
          $cache_instance->save( $cache );
        }
      }
    }
  }

  return $data;
}

function youtube_search( $args = [] ) {
  $defaults = [
    'query' => null,
    'limit' => 20,
    'priority' => 'non_api',
  ];
  $options = array_merge( $defaults, $args );
  $source_options = [
    'query' => $options['query'],
    'limit' => $options['limit']
  ];
  $data = [];

  if ( $options['priority'] === 'non_api' ) {
    $data = youtube_search_non_api( $source_options );
    if ( empty( $data ) )
      $data = youtube_search_api( $source_options );
  }

  else {
    $data = youtube_search_api( $source_options );
    if ( empty( $data ) )
      $data = youtube_search_non_api( $source_options );
  }

  return $data;
}

function youtube_search_non_api( $options = [] ) {
  global $cache_instance;

  $data = [];
  $url = 'https://m.youtube.com/results?search_query=' . urlencode( $options['query'] ) . '&gl=' . option( 'youtube_country_code', 'US' );
  $cache = $cache_instance->getItem( md5( $url ) );

  if ( ! is_null( $cache->get() ) && option( 'use_cache', true) ) {
    $data = json_decode( $cache->get(), true );
  } else {
    $curl = curl( $url, [ 'user_agent' => 'Mozilla/5.0 (Linux; Android 7.0; SM-G935P Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safari/537.36' ] );
    if ( $curl['info']['http_code'] == 200 ) {
      $html = $curl['data'];

      if ( preg_match( '/<div id="initial-data"><!--\s(.*)\s--><\/div>/i', $html, $params ) ) {
        array_shift( $params );

        $params = json_decode( $params[0], true );

        if ( isset( $params['contents']['sectionListRenderer']['contents'] ) )
          foreach ( $params['contents']['sectionListRenderer']['contents'] as $contents )
            foreach ( $contents as $content )
              if ( isset( $content['contents'] ) )
                $items = $content['contents'];

        if ( ! isset( $items ) )
          if ( isset( $params['continuationContents']['itemSectionContinuation']['contents'] ) )
            $items = $params['continuationContents']['itemSectionContinuation']['contents'];

        if ( isset( $items ) ) {
          foreach ( $items as $item ) {
            $item_data = [];

            if ( isset( $item['compactVideoRenderer']['videoId'] ) ) {
              $item_data['id'] = $item['compactVideoRenderer']['videoId'];
              $item_data['image'] = 'https://i.ytimg.com/vi/' . $item_data['id'] . '/default.jpg';
            }

            if ( isset( $item['compactVideoRenderer']['title']['runs'][0]['text'] ) )
              $item_data['title'] = $item['compactVideoRenderer']['title']['runs'][0]['text'];

            if ( isset( $item['compactVideoRenderer']['longBylineText']['runs'][0]['text'] ) )
              $item_data['channel'] = $item['compactVideoRenderer']['longBylineText']['runs'][0]['text'];

            if ( isset( $item['compactVideoRenderer']['lengthText']['runs'][0]['text'] ) ) {
              $item_data['duration'] = $item['compactVideoRenderer']['lengthText']['runs'][0]['text'];

              $exp_duration = explode( ':', $item_data['duration'] );

              if ( count( $exp_duration ) == 2 ) {
                $parsed = date_parse( '00:' . $item_data['duration'] );
                $seconds = ( $parsed['minute'] * 60 ) + $parsed['second'];
              } else {
                $parsed = date_parse( $item_data['duration'] );
                $seconds = ( $parsed['hour'] * 60 * 60 ) + ( $parsed['minute'] * 60 ) + $parsed['second'];
              }

              $item_data['size'] = format_bytes( ( $seconds * ( 192 / 8 ) * 1000 ) );
            }

            if ( $item_data )
              $data[] = $item_data;
          }

          if ( option( 'use_cache', true ) && $data ) {
            $cache->set( json_encode( $data ) )->expiresAfter( option( 'cache_expiration_time', 300 ) );
            $cache_instance->save( $cache );
          }
        }
      }
    }
  }

  return $data;
}

function youtube_search_api( $options = [] ) {
  global $cache_instance;

  $data = [];

  $url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=' . urlencode( $options['query'] ) . '&type=video&regionCode=' . option( 'youtube_country_code', 'US' ) . '&maxResults=' . $options['limit'] . '&key=' . youtube_api_key();
  $cache = $cache_instance->getItem( md5( $url ) );

  if ( ! is_null( $cache->get() ) && option( 'use_cache', true) ) {
    $data = json_decode( $cache->get(), true );
  } else {
    $curl = curl( $url );
    if ( $curl['info']['http_code'] == 200 ) {
      $response = json_decode( $curl['data'], true );
      if ( isset( $response['items'] ) ) {
        foreach ( $response['items'] as $item )
          $video_ids[] = $item['id']['videoId'];

        unset( $item );

        $url = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id=' . implode( $video_ids, ',' ) . '&key=' . youtube_api_key();
        $curl = curl( $url );

        if ( $curl['info']['http_code'] == 200 ) {
          $response = json_decode( $curl['data'], true );

          foreach ( $response['items'] as $item ) {
            $snippet = $item['snippet'];
            $content_details = $item['contentDetails'];

            $item_data['id'] = $item['id'];
            $item_data['title'] = $snippet['title'];
            $item_data['channel'] = $snippet['channelTitle'];
            $item_data['date'] = $snippet['publishedAt'];
            $item_data['image'] = 'https://i.ytimg.com/vi/' . $item['id'] . '/default.jpg';

            $duration = convert_youtube_time( $content_details['duration'] );
            $exp_duration = explode( ':', $duration );

            if ( count( $exp_duration ) == 2 ) {
              $parsed = date_parse( '00:' . $duration );
              $seconds = ( $parsed['minute'] * 60 ) + $parsed['second'];
            } else {
              $parsed = date_parse( $duration );
              $seconds = ( $parsed['hour'] * 60 * 60 ) + ( $parsed['minute'] * 60 ) + $parsed['second'];
            }

            $item_data['duration'] = $duration;
            $item_data['size'] = format_bytes( ( $seconds * ( 192 / 8 ) * 1000 ) );

            $data[] = $item_data;
          }

          if ( option( 'use_cache', true ) && $data ) {
            $cache->set( json_encode( $data ) )->expiresAfter( option( 'cache_expiration_time', 300 ) );
            $cache_instance->save( $cache );
          }
        }
      }
    }
  }

  return $data;
}

function youtube_download( $args = [] ) {
  $defaults = [
    'id' => null,
    'priority' => 'non_api',
  ];
  $options = array_merge( $defaults, $args );
  $source_options = [ 'id' => $options['id'] ];
  $data = [];

  if ( $options['priority'] === 'non_api' ) {
    $data = youtube_download_non_api( $source_options );
    if ( empty( $data ) )
      $data = youtube_download_api( $source_options );
  }

  else {
    $data = youtube_download_api( $source_options );
    if ( empty( $data ) )
      $data = youtube_download_non_api( $source_options );
  }

  return $data;
}

function youtube_download_non_api( $options = [] ) {
  global $cache_instance;

  $data = [];
  $url = 'https://m.youtube.com/watch?v=' . $options['id'];
  $cache = $cache_instance->getItem( md5( $url ) );

  if ( ! is_null( $cache->get() ) && option( 'use_cache', true) ) {
    $data = json_decode( $cache->get(), true );
  } else {
    $curl = curl( $url, [
      'user_agent' => 'Mozilla/5.0 (Linux; Android 7.0; SM-G935P Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safari/537.36',
      'headers' => [ 'Cookie: PREF=al=en-GB&gl=' . option( 'youtube_country_code', 'US' ) ]
    ] );

    if ( $curl['info']['http_code'] == 200 ) {
      $html = $curl['data'];

      if ( preg_match( '/ytInitialPlayerConfig = {(.*);/', $html, $matches ) ) {
        array_shift( $matches );

        $json = '{' . $matches[0];
        $params = json_decode( $json, true );
      }

      if ( preg_match( '/<div id="initial-data"><!--\s(.*)\s--><\/div>/i', $html, $params2 ) ) {
        array_shift( $params2 );

        $params2 = json_decode( $params2[0], true );

        if ( isset( $params2['contents']['singleColumnWatchNextResults']['results']['results']['contents'] ) ) {
          $contents = $params2['contents']['singleColumnWatchNextResults']['results']['results']['contents'];

          foreach ( $contents as $content ) {
            if ( isset( $content['itemSectionRenderer']['contents'][0]['videoMainContentRenderer'] ) ) {
              $item = $content['itemSectionRenderer']['contents'][0]['videoMainContentRenderer'];

              $data['id'] = $options['id'];
              $data['image'] = 'https://i.ytimg.com/vi/' . $data['id'] . '/mqdefault.jpg';

              if ( isset( $item['title']['runs'][0]['text'] ) )
                $data['title'] = $item['title']['runs'][0]['text'];

              if ( isset( $item['shortBylineText']['runs'][0]['text'] ) )
                $data['channel'] = $item['shortBylineText']['runs'][0]['text'];

              if ( isset( $item['dateText']['runs'][0]['text'] ) )
                $data['date'] = strtr( $item['dateText']['runs'][0]['text'], [ 'Published on ' => '' ] );

              $data['duration'] = '';
              $data['size'] = '';

              if ( isset( $params['args']['length_seconds'] ) ) {
                if ( $params['args']['length_seconds'] >= 3600 ) {
                  $data['duration'] = date( 'H:i:s', $params['args']['length_seconds'] );
                } else {
                  $data['duration'] = date( 'i:s', $params['args']['length_seconds'] );
                }

                $exp_duration = explode( ':', $data['duration'] );

                if ( count( $exp_duration ) == 2 ) {
                  $parsed = date_parse( '00:' . $data['duration'] );
                  $seconds = ( $parsed['minute'] * 60 ) + $parsed['second'];
                } else {
                  $parsed = date_parse( $data['duration'] );
                  $seconds = ( $parsed['hour'] * 60 * 60 ) + ( $parsed['minute'] * 60 ) + $parsed['second'];
                }

                $data['size'] = format_bytes( ( $seconds * ( 192 / 8 ) * 1000 ) );
              }

              if ( isset( $item['viewCountText']['runs'][0]['text'] ) )
                $data['views'] = preg_replace( '/([^0-9]+)/', '', $item['viewCountText']['runs'][0]['text'] );

              if ( isset( $item['menu']['menuRenderer']['topLevelButtons'] ) ) {
                foreach ( $item['menu']['menuRenderer']['topLevelButtons'] as $button ) {
                  if ( isset( $button['toggleButtonRenderer']['defaultIcon']['iconType'] ) && $button['toggleButtonRenderer']['defaultIcon']['iconType'] === 'LIKE' ) {
                    $data['likes'] = preg_replace( '/([^0-9]+)/', '', $button['toggleButtonRenderer']['defaultText']['accessibility']['accessibilityData']['label'] );
                  }
                }
              }

              $data['description'] = '';

              if ( isset( $item['description']['runs'] ) )
                foreach ( $item['description']['runs'] as $description )
                  $data['description'].= $description['text'];
            } elseif ( isset( $content['itemSectionRenderer']['contents'] ) ) {
              $related_items = $content['itemSectionRenderer']['contents'];
              foreach ( $related_items as $item ) {
                if ( isset( $item['compactVideoRenderer'] ) ) {
                  $item_data['id'] = $item['compactVideoRenderer']['videoId'];
                  $item_data['image'] = 'https://i.ytimg.com/vi/' . $item_data['id'] . '/mqdefault.jpg';

                  if ( isset( $item['compactVideoRenderer']['title']['runs'][0]['text'] ) )
                    $item_data['title'] = $item['compactVideoRenderer']['title']['runs'][0]['text'];

                  if ( isset( $item['compactVideoRenderer']['longBylineText']['runs'][0]['text'] ) )
                    $item_data['channel'] = $item['compactVideoRenderer']['longBylineText']['runs'][0]['text'];

                  if ( isset( $item['compactVideoRenderer']['lengthText']['runs'][0]['text'] ) ) {
                    $item_data['duration'] = $item['compactVideoRenderer']['lengthText']['runs'][0]['text'];

                    $exp_duration = explode( ':', $item_data['duration'] );

                    if ( count( $exp_duration ) == 2 ) {
                      $parsed = date_parse( '00:' . $item_data['duration'] );
                      $seconds = ( $parsed['minute'] * 60 ) + $parsed['second'];
                    } else {
                      $parsed = date_parse( $item_data['duration'] );
                      $seconds = ( $parsed['hour'] * 60 * 60 ) + ( $parsed['minute'] * 60 ) + $parsed['second'];
                    }

                    $item_data['size'] = format_bytes( ( $seconds * ( 192 / 8 ) * 1000 ) );
                  }

                  $data['related'][] = $item_data;
                }
              }
            }
          }

          if ( option( 'use_cache', true ) && $data ) {
            $cache->set( json_encode( $data ) )->expiresAfter( option( 'cache_expiration_time', 300 ) );
            $cache_instance->save( $cache );
          }
        }
      }
    }
  }

  return $data;
}

function youtube_download_api( $options = [] ) {
  global $cache_instance;

  $url = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id=' . $options['id'] . '&key=' . youtube_api_key();
  $cache = $cache_instance->getItem( md5( $url ) );

  if ( ! is_null( $cache->get() ) && option( 'use_cache', true) ) {
    $data = json_decode( $cache->get(), true );
  } else {
    $curl = curl( $url );
    if ( $curl['info']['http_code'] == 200 ) {
      $response = json_decode( $curl['data'], true );

      if ( isset( $response['items'][0] ) ) {
        $snippet = $response['items'][0]['snippet'];
        $content_details = $response['items'][0]['contentDetails'];
        $statistics = $response['items'][0]['statistics'];

        $data['id'] = $response['items'][0]['id'];
        $data['image'] = 'https://i.ytimg.com/vi/' . $data['id'] . '/mqdefault.jpg';
        $data['title'] = $snippet['title'];
        $data['channel'] = $snippet['channelTitle'];
        $data['date'] = $snippet['publishedAt'];

        $duration = convert_youtube_time( $content_details['duration'] );
        $exp_duration = explode( ':', $duration );

        if ( count( $exp_duration ) == 2 ) {
          $parsed = date_parse( '00:' . $duration );
          $seconds = ( $parsed['minute'] * 60 ) + $parsed['second'];
        } else {
          $parsed = date_parse( $duration );
          $seconds = ( $parsed['hour'] * 60 * 60 ) + ( $parsed['minute'] * 60 ) + $parsed['second'];
        }

        $data['duration'] = $duration;
        $data['size'] = format_bytes( ( $seconds * ( 192 / 8 ) * 1000 ) );
        $data['views'] = $statistics['viewCount'];
        $data['likes'] = $statistics['likeCount'];
        $data['description'] = $snippet['description'];
      }

      if ( option( 'youtube_download_related', 1 ) ) {
        $related_url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&regionCode=' . option( 'youtube_country_code', 'US' ) . '&maxResults=10&relatedToVideoId=' . $options['id'] . '&key=' . youtube_api_key();
        $curl_related = curl( $related_url );

        if ( $curl_related['info']['http_code'] == 200 ) {
          $response = json_decode( $curl_related['data'], true );

          if ( isset( $response['items'] ) ) {
            foreach ( $response['items'] as $item )
              $video_ids[] = $item['id']['videoId'];

            unset( $item );

            $url = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id=' . implode( $video_ids, ',' ) . '&key=' . youtube_api_key();
            $curl = curl( $url );

            if ( $curl['info']['http_code'] == 200 ) {
              $response = json_decode( $curl['data'], true );
              foreach ( $response['items'] as $item ) {
                $snippet = $item['snippet'];
                $content_details = $item['contentDetails'];

                $item_data['id'] = $item['id'];
                $item_data['title'] = $snippet['title'];
                $item_data['channel'] = $snippet['channelTitle'];
                $item_data['date'] = $snippet['publishedAt'];
                $item_data['image'] = 'https://i.ytimg.com/vi/' . $item['id'] . '/mqdefault.jpg';

                $duration = convert_youtube_time( $content_details['duration'] );
                $exp_duration = explode( ':', $duration );

                if ( count( $exp_duration ) == 2 ) {
                  $parsed = date_parse( '00:' . $duration );
                  $seconds = ( $parsed['minute'] * 60 ) + $parsed['second'];
                } else {
                  $parsed = date_parse( $duration );
                  $seconds = ( $parsed['hour'] * 60 * 60 ) + ( $parsed['minute'] * 60 ) + $parsed['second'];
                }

                $item_data['duration'] = $duration;
                $item_data['size'] = format_bytes( ( $seconds * ( 192 / 8 ) * 1000 ) );

                $data['related'][] = $item_data;
              }
            }
          }
        }
      }

      if ( option( 'use_cache', true ) && $data ) {
        $cache->set( json_encode( $data ) )->expiresAfter( option( 'cache_expiration_time', 300 ) );
        $cache_instance->save( $cache );
      }
    }
  }

  return $data;
}

function youtube_api_key() {
  $api_key = false;

  if ( $api_keys = option( 'youtube_api_keys' ) ) {
    $api_key_parts = clean_array( explode( ',', $api_keys ) );
    $api_key = $api_key_parts[array_rand( $api_key_parts, 1 )];
  }

  return $api_key;
}
