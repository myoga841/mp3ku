<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

function bad_word_redirect( $query = '' ) {
  if ( ! $query )
    return false;

  $bad_words = bad_words();

	if ( filter_bad_words( strtolower( $query ), $bad_words, 0 ) ) {
		$exp_title = $static_exp_title = explode( ' ', strtolower( $query ) );

		if ( count( $exp_title ) > 1 ) {
			foreach( $bad_words as $key => $value ) {
				$exp_value = explode( ' ', trim( $value ) );
				if ( count( $exp_value ) > 1 ) {
					foreach( $exp_value as $child_value )
						if ( ( $key = array_search( $child_value, $exp_title ) ) !== false )
							unset( $exp_title[$key] );
				} else {
					if ( ( $key = array_search( $value, $exp_title ) ) !== false )
						unset( $exp_title[$key] );
				}
			}

			if ( count( $exp_title ) > 0 ) {
				if ( count( $exp_title ) != count( $static_exp_title ) )
					$redirect = search_permalink( implode( $exp_title, '-' ) );
			} else {
				$redirect = site_url();
			}
		} else {
			$redirect = site_url();
		}
	}

	return ( isset( $redirect ) ) ? $redirect : false;
}

function bad_words() {
	$bad_words_file = site_dir( option( 'use_default_bad_words', true ) ) . '/data/bad-words.txt';

  if ( ! file_exists( $bad_words_file ) && file_exists( APP . '/data/bad-words.txt' ) )
		$bad_words_file = APP . '/data/bad-words.txt';

  if ( file_exists( $bad_words_file ) ) {
    $bad_words = file_get_contents( $bad_words_file );
		return clean_array( multi_explode( [ "\n", ',' ], $bad_words ) );
  }
}

function filter_bad_words( $haystack, $needle, $offset = 0 ) {
	if ( is_array( $needle ) && ! empty( $needle ) )
		foreach( $needle as $word )
			if ( stristr( $haystack, trim( $word ) ) )
				return true;

	return false;
}

function save_recent_search( $keyword = null ) {
  if ( ! is_null( $keyword ) && strlen( $keyword ) >= 2 && strlen( $keyword ) <= 200 && ! preg_match( '/(3gp|mp4|abd|ab d|a b d|devil|death|divil|die|de vi|alluc|animetoon|ball|bikini|brasher|boston|cucirca|content|girlfriend|kickass|kyle|megashare|motionempire|movie4k|primewire|putlocker|solarmovie|sportpesa|torrent|unfriended|video|vodly|vuclip|watch|www|\.ac|\.ca|\.ch|\.co|\.in|\.info|\.is|\.me|\.net|\.nl|\.org|\.ph|\.tv|\.us|\.vn)/i', $keyword ) ) {
    $keyword = strip_tags( $keyword );
		$keyword = sanitize_title( $keyword );
		$keyword = rawurldecode( $keyword );
		$keyword = str_replace( [ '?', '!', '/', '#', ':', "'", '"' ], '', $keyword );
		$keyword = str_replace( [ '-', '.', '+' ], ' ', $keyword );
		$keyword = strtolower( $keyword );

		if ( strlen( $keyword ) > 200 )
			$keyword = substr( $keyword, 0, 200 );

		$keyword = trim( $keyword );

    $data_file = site_dir( option( 'use_default_data', true ) ) . '/data/search.json';

    if ( file_exists( $data_file ) ) {
      $data = json_decode( file_get_contents( $data_file ), true );
      $slugs = array_column( $data, 'slug' );
    } else {
      $data = [];
      $slugs = [];
    }

    $item = [
      'keyword' => $keyword,
      'slug' => clean_uri( $keyword ),
      'datetime' => date( 'Y-m-d H:i:s' ),
      'count' => 1
    ];

    $exists = array_search( $item['slug'], $slugs );

    if ( $exists === false ) {
      if ( count( $data ) >= option( 'max_recent_search_to_save', 5000 ) )
        array_pop( $data );

      array_unshift( $data, $item );
    } else {
      $data[$exists]['datetime'] = date( 'Y-m-d H:i:s' );
      $data[$exists]['count'] += 1;
    }

    if ( ! is_dir( dirname( $data_file ) ) )
      @mkdir( dirname( $data_file ), 0775, true );

    @file_put_contents( $data_file, json_encode( $data, JSON_PRETTY_PRINT ) );
  }
}

function save_stt() {
  if ( isset( $_SERVER['HTTP_REFERER'] ) && $_SERVER['HTTP_REFERER'] ) {
  	$referer = $_SERVER['HTTP_REFERER'];
  	$referer = str_replace( '?', '?masterclass=1&', $referer );

    parse_str( $referer, $stt );

    if ( ! isset( $stt['q'] ) || isset( $stt['q'] ) && empty( $stt['q'] ) )
      return;

    if ( preg_match( '/google|bing|aol|dogpile/', $referer ) ) {
  		$keyword = $stt['q'];
  	} elseif ( preg_match( '/yahoo/', $referer ) ) {
  		$keyword = $stt['p'];
  	} elseif ( preg_match( '/' . HOST . '/', $referer ) ) {
  		$keyword = '';
  	} else {
      $keyword = '';
    }

    if ( strlen( $keyword ) >= 2 && strlen( $keyword ) <= 200 && ! preg_match( '/(3gp|mp4|abd|ab d|a b d|devil|death|divil|die|de vi|alluc|animetoon|ball|bikini|brasher|boston|cucirca|content|girlfriend|kickass|kyle|megashare|motionempire|movie4k|primewire|putlocker|solarmovie|sportpesa|torrent|unfriended|video|vodly|vuclip|watch|www|\.ac|\.ca|\.ch|\.co|\.in|\.info|\.is|\.me|\.net|\.nl|\.org|\.ph|\.tv|\.us|\.vn)/i', $keyword ) ) {
      $keyword = strip_tags( $keyword );
  		$keyword = sanitize_title( $keyword );
  		$keyword = rawurldecode( $keyword );
  		$keyword = str_replace( [ '?', '!', '/', '#', ':', "'", '"' ], '', $keyword );
  		$keyword = str_replace( [ '-', '.', '+' ], ' ', $keyword );
  		$keyword = strtolower( $keyword );

  		if ( strlen( $keyword ) > 200 )
  			$keyword = substr( $keyword, 0, 200 );

  		$keyword = trim( $keyword );

      $data_file = site_dir( option( 'use_default_data', true ) ) . '/data/stt.json';

      if ( file_exists( $data_file ) ) {
        $data = json_decode( file_get_contents( $data_file ), true );
        $slugs = array_column( $data, 'slug' );
      } else {
        $data = [];
        $slugs = [];
      }

      $item = [
        'keyword' => $keyword,
        'slug' => clean_uri( $keyword ),
        'datetime' => date( 'Y-m-d H:i:s' ),
        'count' => 1
      ];

      $exists = array_search( $item['slug'], $slugs );

      if ( $exists === false ) {
        if ( count( $data ) >= option( 'max_stt_to_save', 5000 ) )
          array_pop( $data );

        array_unshift( $data, $item );
      } else {
        $data[$exists]['datetime'] = date( 'Y-m-d H:i:s' );
        $data[$exists]['count'] += 1;
      }

      if ( ! is_dir( dirname( $data_file ) ) )
        @mkdir( dirname( $data_file ), 0775, true );

      @file_put_contents( $data_file, json_encode( $data, JSON_PRETTY_PRINT ) );
    }
  }
}

function keywords_dir() {
  return site_dir( option( 'use_default_keywords', true ) ) . '/keywords';
}

function random_keywords( $limit = 20 ) {
  $keywords_files = glob( keywords_dir() . '/*' );
  $keywords = [];

  if ( $keywords_files ) {
    $keywords_file = $keywords_files[array_rand( $keywords_files, 1 )];
    $keywords = clean_array( file( $keywords_file ) );
    $keywords = array_map( 'ucwords', $keywords );

    shuffle( $keywords );

    $keywords = array_slice( $keywords, 0, $limit );
  }

  return $keywords;
}

function keywords_by_file( $name, $limit = 20, $random = true ) {
  $keywords_file = glob( keywords_dir() . '/' . $name );
  $keywords = [];

  if ( file_exists( $keywords_file ) ) {
    $keywords = clean_array( file( $keywords_file ) );
    $keywords = array_map( 'ucwords', $keywords );

    if ( $random )
      shuffle( $keywords );

    $keywords = array_slice( $keywords, 0, $limit );
  }

  return $keywords;
}

function recent_search( $limit = 20, $order_by = 'recent' ) {
  $recent_search_file = site_dir( option( 'use_default_data', true ) ) . '/data/search.json';
  $keywords = [];

  if ( file_exists( $recent_search_file ) ) {
    $items = json_decode( file_get_contents( $recent_search_file ), true );
    if ( $items ) {
      if ( $order_by === 'random' ) {
        shuffle( $items );
      } elseif ( $order_by === 'popular' ) {
        $items = multi_sort( [ $items, 'count', SORT_DESC, 'datetime', SORT_DESC ] );
      }

      $items = array_slice( $items, 0, 20 );

      foreach ( $items as $item )
        $keywords[] = ucwords( $item['keyword'] );
    }
  }

  return $keywords;
}

function stt( $limit = 20, $random = false, $order_by = 'popular' ) {
  $stt_file = site_dir( option( 'use_default_data', true ) ) . '/data/stt.json';
  $keywords = [];

  if ( file_exists( $stt_file ) ) {
    $items = json_decode( file_get_contents( $stt_file ), true );
    if ( $items ) {
      if ( $order_by === 'random' ) {
        shuffle( $items );
      } elseif ( $order_by === 'popular' ) {
        $items = multi_sort( [ $items, 'count', SORT_DESC, 'datetime', SORT_DESC ] );
      }

      $items = array_slice( $items, 0, 20 );

      foreach ( $items as $item )
        $keywords[] = ucwords( $item['keyword'] );
    }
  }

  return $keywords;
}

function curl( $url, $options = [] ) {
  $defaults = [
    'encoding' => 'gzip,deflate',
    'user_agent' => user_agent(),
    'timeout' => 30,
    'get' => 'all'
  ];
  $options  = array_merge( $defaults, $options );
  $proxies  = proxies();

  if ( $proxies )
    $proxy = $proxies[array_rand( $proxies, 1)];

  $ch = curl_init();

  curl_setopt( $ch, CURLOPT_URL, $url );
  curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );

  if ( $options['encoding'] )
    curl_setopt( $ch, CURLOPT_ENCODING, $options['encoding'] );

  curl_setopt( $ch, CURLOPT_USERAGENT, $options['user_agent'] );
  curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
  curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, $options['timeout'] );
  curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, TRUE );

  if ( isset( $options['header'] ) )
    curl_setopt( $ch, CURLOPT_HEADER, TRUE );

  if ( isset( $proxy ) && $proxy )
    curl_setopt( $ch, CURLOPT_PROXY, $proxy );
  if ( isset( $options['referer'] ) && $options['referer'] )
    curl_setopt( $ch, CURLOPT_REFERER, $options['referer'] );
  if ( isset( $options['headers'] ) && $options['headers'] )
    curl_setopt( $ch, CURLOPT_HTTPHEADER, $options['headers'] );

  if ( $options['get'] == 'all' ) {
    $data = curl_exec( $ch );

    if ( isset( $options['header'] ) ) {
      $data_parts = explode( "\r\n\r\n", $data, 2 );
      $headers = $data_parts[0];
      $header_parts = clean_array( explode( "\n", $headers ) );

      foreach ( $header_parts as $header_part ) {
        $header_part_parts = clean_array( explode( ':', $header_part, 2 ) );
        if ( count( $header_part_parts ) <= 1 ) {
          $header_params[] = $header_part_parts[0];
        } else {
          $header_params[$header_part_parts[0]] = $header_part_parts[1];
        }
      }

      $result['headers'] = $header_params;
      $result['data'] = $data_parts[1];
    } else {
      $result['data'] = $data;
    }

    $result['info'] = curl_getinfo( $ch );
  } elseif ( $options['get'] == 'info' ) {
    $result['info'] = curl_getinfo( $ch );
  }

  curl_close( $ch );

  return $result;
}

function user_agent() {
  $user_agents_file = APP . '/data/ua.txt';

  if ( file_exists( $user_agents_file ) ) {
    $user_agents = clean_array( file( $user_agents_file ) );
    $user_agent = $user_agents[array_rand( $user_agents, 1)];
  } else {
    $user_agent = '';
  }

  return $user_agent;
}

function proxies() {
  $proxies_file = site_dir( option( 'use_default_proxies', true ) ) . '/data/proxies.txt';

  if ( ! file_exists( $proxies_file ) && file_exists( APP . '/data/proxies.txt' ) )
		$proxies_file = APP . '/data/proxies.txt';

  if ( file_exists( $proxies_file ) ) {
    $proxies = file_get_contents( $proxies_file );
		return clean_array( multi_explode( [ "\n", ',' ], $proxies ) );
  }

  return [];
}

function convert_youtube_time( $time ) {
  $start = new DateTime( '@0' );
  $start->add( new DateInterval( $time ) );
  return $start->format( 'i:s' );
}

function format_bytes( $bytes, $precision = 2 ) {
	$units = [ 'B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB' ];
	$bytes = max( $bytes, 0);
	$pow = floor( ( $bytes ? log( $bytes ) : 0 ) / log( 1024 ) );
	$pow = min( $pow, count( $units ) - 1 );
	$bytes /= pow( 1024, $pow );
	return round( $bytes, $precision ) . ' ' . $units[$pow];
}

function currency_format( $num ) {
  if ( $num > 1000 ) {
    $x = round( $num );
    $x_number_format = number_format( $x );
    $x_array = explode( ',', $x_number_format );
    $x_parts = [ 'k', 'm', 'b', 't' ];
    $x_count_parts = count( $x_array ) - 1;
    $x_display = $x;
    $x_display = $x_array[0] . ( ( int ) $x_array[1][0] !== 0 ? '.' . $x_array[1][0] : '' );
    $x_display.= $x_parts[$x_count_parts - 1];

    return $x_display;
  }

  return $num;
}
