<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

function seo() {
  seo_meta_all();
  seo_meta_robots();
  seo_canonical_url( false );
}

function seo_meta_all() {
  global $mc;

  $canonical_url = canonical_url( false );
  $twitter_card_summary_type = 'summary';

  if ( route( 'index' ) ) {
    $og_type = 'website';
  } elseif ( route( 'genre' ) ) {
    $og_type = 'object';
  }

  if ( route( 'index' ) && option( 'index_meta_description' ) ) {
    $meta_description = strtr( option( 'index_meta_description' ), [
      '%site_name%' => option( 'site_name' ),
      '%site_tagline%' => option( 'site_tagline' ),
      '%domain%' => DOMAIN
    ] );

    if ( option( 'index_meta_image_url' ) )
      $meta_image = option( 'index_meta_image_url' );
  }

  elseif ( route( 'genre' ) && option( 'genre_meta_description' ) ) {
    $meta_description = strtr( option( 'genre_meta_description' ), [
      '%name%' => $mc['genre']['name'],
      '%site_name%' => option( 'site_name' ),
      '%domain%' => DOMAIN
    ] );
    $meta_image = $mc['genre']['items'][0]['image'];
  }

  elseif ( route( 'search' ) ) {
    if ( option( 'search_meta_description' ) ) {
      $meta_description = strtr( option( 'search_meta_description' ), [
        '%query%' => query(),
        '%size%' => $mc['search'][0]['size'],
        '%site_name%' => option( 'site_name' ),
        '%domain%' => DOMAIN
      ] );
    }

    $twitter_card_summary_type = 'summary_large_image';
    $meta_image = $mc['search'][0]['image'];
  }

  elseif ( route( 'download' ) ) {
    if ( option( 'download_meta_description' ) ) {
      $meta_description = trim( str_replace(
        [ '%title%', '%size%', '%duration%', '%channel%', '%date%', '%site_name%', '%domain%' ],
        [ $mc['download']['title'], $mc['download']['size'], $mc['download']['duration'], $mc['download']['channel'], $mc['download']['date'], option( 'site_name' ), DOMAIN ],
        option( 'single_meta_description' )
      ) );
    }

    $og_type = 'article';
    $twitter_card_summary_type = 'summary_large_image';
    $meta_image = $mc['download']['image'];
  }

  if ( isset( $meta_description ) )
    echo '<meta name="description" content="' . $meta_description . '" />' . "\n";
  if ( isset( $keywords ) && $keywords )
    echo '<meta property="keywords" content="' . $keywords . '" />' . "\n";

  echo '<meta property="og:url" content="' . $canonical_url . '" />' . "\n";

  if ( isset( $og_type ) )
    echo '<meta property="og:type" content="' . $og_type . '" />' . "\n";

  echo '<meta property="og:title" content="' . site_title() . '" />' . "\n";

  if ( isset( $meta_description ) )
    echo '<meta property="og:description" content="' . $meta_description . '" />' . "\n";
  if ( isset( $meta_image ) )
    echo '<meta property="og:image" content="' . $meta_image . '" />' . "\n";

  echo '<meta name="twitter:card" content="' . $twitter_card_summary_type . '">' . "\n";
  echo '<meta name="twitter:title" content="' . site_title() . '" />' . "\n";

  if ( isset( $meta_description ) )
    echo '<meta name="twitter:description" content="' . $meta_description . '" />' . "\n";
  if ( isset( $meta_image ) )
    echo '<meta name="twitter:image" content="' . $meta_image . '" />' . "\n";
}

function seo_meta_robots() {
  if ( route( 'index' ) ) {
    $meta_robots = option( 'index_meta_robots' );
  } elseif ( route( 'genre' ) && option( 'genre_meta_robots' ) ) {
    $meta_robots = option( 'genre_meta_robots' );
  } elseif ( route( 'search' ) && option( 'search_meta_robots' ) ) {
    $meta_robots = option( 'search_meta_robots' );
  } elseif ( route( 'download' ) && option( 'download_meta_robots' ) ) {
    $meta_robots = option( 'download_meta_robots' );
  }

  if ( isset( $meta_robots ) )
    echo '<meta name="robots" content="' . $meta_robots . '" />' . "\n";
}

function seo_canonical_url( ) {
  echo '<link rel="canonical" href="' . canonical_url( false ) . '" />' . "\n";
}
