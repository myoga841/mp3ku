<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

if ( route( 'sitemap-terms' ) ) {
  $__type = (int) route_vars( 'type' );

  if ( $__type === 1 ) {
    $__file = site_dir( option( 'use_default_data', true ) ) . '/data/stt.json';
  } elseif ( $__type === 2 ) {
    $__file = site_dir( option( 'use_default_data', true ) ) . '/data/search.json';
  }

  if ( isset( $__file ) && file_exists( $__file ) ) {
    $__data = json_decode( file_get_contents( $__file ), true );

    if ( $__data ) {
      foreach ( $__data as $__item ) {
        $mc['sitemap'][] = search_permalink( $__item['keyword'] );
        unset( $__item );
      }
    } else {
      $error404 = true;
      return;
    }

    unset( $__data );
  } else {
    $error404 = true;
    return;
  }

  unset( $__type, $__file );
}

elseif ( route( 'sitemap-keywords' ) ) {
  $__file = (int) route_vars( 'file' );
  $__page = (int) route_vars( 'page' );

  if ( $__file > 0 && $__page > 0 ) {
    $__limit = option( 'sitemap_limit_per_page', 10000 );
    $__start = ( $__page - 1 ) * $__limit;
    $__keyword_files = glob( site_dir( option( 'use_default_keywords', true ) ) . '/keywords/*.txt' );

    if ( isset( $__keyword_files[$__file-1] ) ) {
      $__keyword_file = $__keyword_files[$__file-1];
      $__keywords = clean_array( file( $__keyword_file ) );
      $__keywords = array_slice( $__keywords, $__start, $__limit );

      shuffle( $__keywords );

      foreach ( $__keywords as $__keyword ) {
        $mc['sitemap'][] = search_permalink( $__keyword );
        unset( $__keyword );
      }
    }
  }

  if ( ! isset( $mc['sitemap'] ) ) {
    $error404 = true;
    return;
  }
}

elseif ( route( 'sitemap-index' ) ) {
  $mc['sitemap']['misc'][] = sitemap_misc_permalink();

  $__stt_file = site_dir( option( 'use_default_data', true ) ) . '/data/stt.json';
  $__recent_search_file = site_dir( option( 'use_default_data', true ) ) . '/data/search.json';

  if ( file_exists( $__stt_file ) )
    $mc['sitemap']['terms'][] = sitemap_terms_permalink( 1 );

  if ( file_exists( $__recent_search_file ) )
    $mc['sitemap']['terms'][] = sitemap_terms_permalink( 2 );

  $__keyword_files = glob( site_dir( option( 'use_default_keywords', true ) ) . '/keywords/*.txt' );

  if ( $__keyword_files ) {
    foreach( $__keyword_files as $__keyword_file_key => $__keyword_file ) {
      $__keywords = file( $__keyword_file );
      $__keyword_count = count( $__keywords );

      if ( $__keyword_count > 0 )
        for ( $i = 1; $i <= ( ceil( $__keyword_count / (int) option( 'sitemap_limit_per_page', 10000 ) ) ); $i++ )
          $mc['sitemap']['keywords'][] = sitemap_keywords_permalink( ( $__keyword_file_key + 1 ), $i );

      unset( $__keyword_file_key, $__keyword_file, $__keywords, $__keyword_count );
    }
  }

  unset( $__keyword_files );
}

/*----------------------------------------------------------------------------*/

header( 'Content-Type: application/xml' );
