<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

$__pages_file = site_dir( option( 'use_default_pages', true ) ) . '/config/pages.php';

if ( file_exists( $__pages_file ) )
  $__pages = require_once $__pages_file;

unset( $__pages_file );

if ( ! isset( $__pages ) ) {
  $error404 = true;
  return;
}

$__pages_slug = array_column( $__pages, 'slug' );

if ( ! in_array( route_vars( 'name' ), $__pages_slug ) ) {
  $error404 = true;
  return;
}

/*----------------------------------------------------------------------------*/

$mc['page'] = $__pages[array_search( route_vars( 'name' ), $__pages_slug )];

unset( $__pages, $__pages_slug );

$mc['page']['template'] = str_replace(
  [ '%base%', '%default_site%', '%site%', '%theme%', '%pages%' ],
  [ BASE, DEFAULT_SITE, SITE, THEME, site_dir( option( 'use_default_pages', true ) ) . '/pages' ],
  $mc['page']['template']
);

if ( file_exists( $mc['page']['template'] ) ) {
  ob_start();

  include $mc['page']['template'];

  $page = ob_get_clean();
  $page = str_replace(
    [ '%domain%', '%site_name%', '%site_url%' ],
    [ DOMAIN, option( 'site_name' ), site_url() ],
    $page
  );

  $mc['page']['content'] = $page;
}

/*----------------------------------------------------------------------------*/

$mc['site_title'] = strtr( option( 'page_title', '%name%' ), [
  '%name%' => $mc['page']['name']
] );
