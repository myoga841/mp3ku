<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

$mc['download'] = youtube_download( [
  'id' => base64__decode( route_vars( 'id' ) ),
  'priority' => option( 'youtube_download_priority', 'non_api' )
] );

if ( empty( $mc['download'] ) )
  redirect( site_url() );

/*----------------------------------------------------------------------------*/

$mc['site_title'] = strtr( option( 'download_title', '(%size%) %title%' ), [
  '%title%' => $mc['download']['title'],
  '%size%' => $mc['download']['size'],
  '%duration%' => $mc['download']['duration']
] );
