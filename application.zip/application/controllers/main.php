<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

$agc_files = glob( APP . '/agc/*' );

if ( $agc_files )
  foreach ( $agc_files as $agc_file )
    require_once $agc_file;
