<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

if ( $redirect_if_bad_word = bad_word_redirect( query() ) )
  redirect( $redirect_if_bad_word );

/*----------------------------------------------------------------------------*/

if ( option( 'save_recent_search', true ) )
  save_recent_search( query() );

if ( option( 'save_stt', true ) )
  save_stt();

/*----------------------------------------------------------------------------*/

$mc['search'] = youtube_search( [
  'query' => query(),
  'limit' => option( 'youtube_search_limit', 20 ),
  'priority' => option( 'youtube_search_priority', 'non_api' )
] );

if ( empty( $mc['search'] ) )
  redirect( site_url() );

/*----------------------------------------------------------------------------*/

$mc['site_title'] = strtr( option( 'search_title', '(%size%) %query%' ), [
  '%size%' => $mc['search'][0]['size'],
  '%query%' => query()
] );
