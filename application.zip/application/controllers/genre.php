<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

$__slug = route_vars( 'name' );
$__genre_slugs = array_column( $config['genres'], 'slug' );

if ( ! in_array( $__slug, $__genre_slugs ) ) {
  $error404 = true;
  return;
}

foreach ( $config['genres'] as $__genre ) {
  if ( $__genre['slug'] === $__slug )
    $mc['genre'] = $__genre;

  unset( $__genre );
}

unset( $__slug, $__genre_slugs );

$mc['genre']['items'] = itunes_genre( $mc['genre']['id'], 24 );

if ( empty( $mc['genre']['items'] ) )
  redirect( site_url() );

/*----------------------------------------------------------------------------*/

$mc['site_title'] = strtr( option( 'genre_title', '%name% Songs' ), [ '%name%' => $mc['genre']['name'] ] );
