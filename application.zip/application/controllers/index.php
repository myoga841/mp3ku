<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

$mc['site_title'] = strtr( option( 'index_title', '%site_tagline%' ), [ '%site_tagline%' => option( 'site_tagline' ) ] );
