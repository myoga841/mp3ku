<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

$mc_filters = [];
$mc_merged_filters = [];
$mc_actions = [];
$mc_current_filter = [];

function add_filter( $tag, $function_to_add, $priority = 10, $accepted_args = 1 ) {
	global $mc_filters, $mc_merged_filters;

	$idx = _filter_build_unique_id( $tag, $function_to_add, $priority );
	$mc_filters[$tag][$priority][$idx] = [ 'function' => $function_to_add, 'accepted_args' => $accepted_args ];

  unset( $mc_merged_filters[ $tag ] );

	return true;
}

function remove_filter( $tag, $function_to_remove, $priority = 10 ) {
	global $mc_filters, $mc_merged_filters;

	$function_to_remove = filter_build_unique_id( $tag, $function_to_remove, $priority );
	$r = isset( $mc_filters[$tag][$priority][$function_to_remove] );

	if ( true === $r ) {
		unset( $mc_filters[$tag][$priority][$function_to_remove] );

    if ( empty( $mc_filters[$tag][$priority] ) )
			unset( $mc_filters[$tag][$priority] );

    unset( $mc_merged_filters[$tag] );
	}

	return $r;
}

function remove_all_filters( $tag, $priority = false ) {
	global $mc_filters, $mc_merged_filters;

	if ( isset( $mc_filters[$tag] ) ) {
		if ( false !== $priority && isset( $mc_filters[$tag][$priority] ) ) {
			unset( $mc_filters[$tag][$priority] );
		} else {
			unset( $mc_filters[$tag] );
		}
	}

	if ( isset( $mc_merged_filters[$tag] ) )
		unset( $mc_merged_filters[$tag] );

	return true;
}

function has_filter( $tag, $function_to_check = false ) {
	global $mc_filters;

	$has = ! empty( $mc_filters[$tag] );

	if ( false === $function_to_check || false == $has ) {
		return $has;
	} if ( ! $idx = filter_build_unique_id( $tag, $function_to_check, false ) ) {
		return false;
  }

	foreach ( ( array ) array_keys( $mc_filters[$tag] ) as $priority )
		if ( isset( $mc_filters[$tag][$priority][$idx] ) )
			return $priority;

	return false;
}

function apply_filters( $tag, $value ) {
	global $mc_filters, $mc_merged_filters, $mc_current_filter;

  $args = [];

	if ( isset( $mc_filters['all'] ) ) {
		$mc_current_filter[] = $tag;
    $args = func_get_args();

    _call_all_hook( $args );
	}

	if ( ! isset( $mc_filters[$tag] ) ) {
    if ( isset( $mc_filters['all'] ) )
			array_pop( $mc_current_filter );

    return $value;
  }

	if ( ! isset( $mc_filters['all'] ) )
    $mc_current_filter[] = $tag;

  if ( ! isset( $mc_merged_filters[ $tag ] ) ) {
    ksort( $mc_filters[$tag] );
    $mc_merged_filters[$tag] = true;
  }

	reset( $mc_filters[ $tag ] );

	if ( empty( $args ) )
    $args = func_get_args();

	do {
    foreach( ( array ) current( $mc_filters[$tag] ) as $the_ )

		if ( ! is_null( $the_['function'] ) ) {
			$args[1] = $value;
			$value = call_user_func_array( $the_['function'], array_slice( $args, 1, ( int ) $the_['accepted_args'] ) );
		}
	} while ( next( $mc_filters[$tag] ) !== false );

	array_pop( $mc_current_filter );

	return $value;
}

function apply_filters_ref_array( $tag, $args ) {
	global $mc_filters, $mc_merged_filters, $mc_current_filter;

	if ( isset( $mc_filters['all'] ) ) {
    $mc_current_filter[] = $tag;
    $all_args = func_get_args();

    _call_all_hook( $all_args );
	}

	if ( ! isset( $mc_filters[$tag] ) ) {
    if ( isset( $mc_filters['all'] ) )
			array_pop( $mc_current_filter );

		return $args[0];
	}

	if ( ! isset( $mc_filters['all'] ) )
    $mc_current_filter[] = $tag;

  if ( ! isset( $mc_merged_filters[ $tag ] ) ) {
    ksort( $mc_filters[$tag] );
    $mc_merged_filters[$tag] = true;
	}

	reset( $mc_filters[ $tag ] );

	do {
    foreach( ( array ) current( $mc_filters[$tag] ) as $the_ )

		if ( ! is_null( $the_['function'] ) )
			$args[0] = call_user_func_array( $the_['function'], array_slice( $args, 0, ( int ) $the_['accepted_args'] ) );
	} while ( next( $mc_filters[$tag] ) !== false );

	array_pop( $mc_current_filter );

	return $args[0];
}

function add_action( $tag, $function_to_add, $priority = 10, $accepted_args = 1 ) {
	return add_filter( $tag, $function_to_add, $priority, $accepted_args );
}

function has_action( $tag, $function_to_check = false ) {
	return has_filter( $tag, $function_to_check );
}

function remove_action( $tag, $function_to_remove, $priority = 10 ) {
	return remove_filter( $tag, $function_to_remove, $priority );
}

function remove_all_actions( $tag, $priority = false ) {
	return remove_all_filters( $tag, $priority );
}

function do_action( $tag, $arg = '' ) {
	global $mc_filters, $mc_merged_filters, $mc_current_filter, $mc_actions;

	if ( ! isset( $mc_actions ) )
    $mc_actions = [];

	if ( ! isset( $mc_actions[$tag] ) ) {
    $mc_actions[$tag] = 1;
	} else {
    ++$mc_actions[$tag];
  }

	if ( isset( $mc_filters['all'] ) ) {
    $mc_current_filter[] = $tag;
    $all_args = func_get_args();

    _call_all_hook( $all_args );
	}

	if ( ! isset( $mc_filters[$tag] ) ) {
    if ( isset( $mc_filters['all'] ) )
			array_pop( $mc_current_filter );

    return;
	}

	if ( ! isset( $mc_filters['all'] ) )
    $mc_current_filter[] = $tag;

	$args = [];

	if ( is_array( $arg ) && 1 == count( $arg ) && isset( $arg[0] ) && is_object( $arg[0] ) ) {
    $args[] =& $arg[0];
	} else {
    $args[] = $arg;
	}

	for ( $a = 2; $a < func_num_args(); $a++ )
    $args[] = func_get_arg( $a );

  if ( ! isset( $mc_merged_filters[ $tag ] ) ) {
    ksort( $mc_filters[$tag] );
    $mc_merged_filters[ $tag ] = true;
	}

	reset( $mc_filters[ $tag ] );

	do {
    foreach ( ( array ) current( $mc_filters[$tag] ) as $the_ )

		if ( ! is_null( $the_['function'] ) )
			call_user_func_array( $the_['function'], array_slice( $args, 0, ( int ) $the_['accepted_args'] ) );
	} while ( next( $mc_filters[$tag] ) !== false );

	array_pop( $mc_current_filter );
}

function do_action_ref_array( $tag, $args ) {
	global $mc_filters, $mc_merged_filters, $mc_current_filter, $mc_actions;

	if ( ! isset( $mc_actions ) )
		$mc_actions = [];

	if ( ! isset( $mc_actions[$tag] ) ) {
		$mc_actions[$tag] = 1;
	} else {
		++$mc_actions[$tag];
	}

	if ( isset( $mc_filters['all'] ) ) {
		$mc_current_filter[] = $tag;
		$all_args = func_get_args();

    _call_all_hook( $all_args );
	}

	if ( ! isset( $mc_filters[$tag] ) ) {
		if ( isset( $mc_filters['all'] ) )
			array_pop( $mc_current_filter );

		return;
	}

	if ( ! isset( $mc_filters['all'] ) ) {
		$mc_current_filter[] = $tag;
  }

	if ( ! isset( $mc_merged_filters[ $tag ] ) ) {
		ksort( $mc_filters[$tag] );
		$mc_merged_filters[ $tag ] = true;
	}

	reset( $mc_filters[ $tag ] );

	do {
		foreach( ( array ) current( $mc_filters[$tag] ) as $the_ )

    if ( ! is_null( $the_['function'] ) )
      call_user_func_array( $the_['function'], array_slice( $args, 0, ( int ) $the_['accepted_args'] ) );
	} while ( next( $mc_filters[$tag] ) !== false );

	array_pop( $mc_current_filter );
}

function did_action( $tag ) {
	global $mc_actions;

	if ( ! isset( $mc_actions ) || ! isset( $mc_actions[$tag] ) )
    return 0;

	return $mc_actions[$tag];
}

function current_filter() {
	global $mc_current_filter;
	return end( $mc_current_filter );
}

function current_action() {
	return current_filter();
}

function doing_filter( $filter = null ) {
	global $mc_current_filter;

	if ( null === $filter )
    return ! empty( $mc_current_filter );

	return in_array( $filter, $mc_current_filter );
}

function doing_action( $action = null ) {
	return doing_filter( $action );
}

function _filter_build_unique_id( $tag, $function, $priority ) {
	global $mc_filters;

	static $filter_id_count = 0;

	if ( is_string( $function ) )
    return $function;

	if ( is_object( $function ) ) {
    $function = [ $function, '' ];
	} else {
    $function = ( array ) $function;
	}

	if ( is_object( $function[0] ) ) {
    if ( function_exists( 'spl_object_hash' ) ) {
			return spl_object_hash( $function[0] ) . $function[1];
    } else {
			$obj_idx = get_class( $function[0] ) . $function[1];

			if ( ! isset( $function[0]->filter_id ) ) {
				if ( false === $priority )
					return false;

				$obj_idx .= isset( $mc_filters[$tag][$priority] ) ? count( ( array ) $mc_filters[$tag][$priority] ) : $filter_id_count;
				$function[0]->filter_id = $filter_id_count;
				++$filter_id_count;
			} else {
				$obj_idx .= $function[0]->filter_id;
			}

			return $obj_idx;
    }
	} else if ( is_string( $function[0] ) ) {
		return $function[0].$function[1];
	}
}

function __call_all_hook( $args ) {
	global $mc_filters;

	reset( $mc_filters['all'] );

	do {
    foreach( ( array ) current( $mc_filters['all'] ) as $the_ )

    if ( ! is_null( $the_['function'] ) )
			call_user_func_array( $the_['function'], $args );
	} while ( next( $mc_filters['all'] ) !== false );
}
