<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

function theme_uri() {
  return site_url() . '/themes/' . option( 'theme' );
}

function the_header() {
  do_action( 'the_header' );
}

function the_footer() {
  do_action( 'the_footer' );
}

function site_title() {
  global $mc;

  if ( isset( $mc['full_site_title'] ) ) {
    $site_title = $mc['full_site_title'];
  } else {
    if ( ! isset( $mc['site_title'] ) )
      $mc['site_title'] = '';

    $site_title_position = apply_filters( 'site_title_position', option( 'title_position', '%site_title% %sep% %site_name%' ) );
    $site_title = strtr( $site_title_position, [
      '%site_title%'  => $mc['site_title'],
      '%sep%'         => title_separator(),
      '%site_name%'   => option( 'site_name' )
    ] );
  }

  return apply_filters( 'site_title', $site_title );
}

function title_separator() {
  return apply_filters( 'title_separator', option( 'title_separator', '&#8211;' ) );
}

function register_stylesheet( $file_url = '', $media = 'all' ) {
  echo '<link rel="stylesheet" type="text/css" media="' . $media . '" href="' . $file_url . '" />' . "\n";
}

function register_javascript( $file_url ) {
  echo '<script type="text/javascript" src="' . $file_url . '"></script>' . "\n";
}

function register_localize_script( $key, $args ) {
  $output = '<script type="text/javascript">' . "\n";
	$output.= "/* <![CDATA[ */\n";
	$output.= 'var ' . $key . ' = ' . json_encode( $args ) . ';' . "\n";
	$output.= "/* ]]> */\n";
	$output.= '</script>' . "\n";

  echo $output;
}

function has_nav_menu( $id ) {
  global $config;
  return isset( $config['menus'][$id] );
}

function nav_menu( $id ) {
  global $config;
  if ( isset( $config['menus'][$id] ) )
    return create_nav_menus_links( $config['menus'][$id] );
}

function create_nav_menus_links( $menus = [], $child = false ) {
  global $uri;

  if ( $menus ) {
    $stop_current = false;
    $output = '<ul' . ( ( $child ) ? ' class="children"' : '' ) . '>' . "\n";

    foreach ( $menus as $index => $menu ) {
      if ( ! isset( $menu['url'] ) && ! isset( $menu['label'] ) )
        continue;

      $menu['url'] = strtr( $menu['url'], [ '%site_url%' => site_url() ] );

      $menu_url_parts = explode( '@', $menu['url'] );

      if ( count( $menu_url_parts ) > 1 ) {
        $function = $menu_url_parts[0];

        array_shift( $menu_url_parts );

        if ( function_exists( $function ) )
          $menu['url'] = call_user_func_array( $function, $menu_url_parts );
      }

      $output.= '<li';

      $classes = [];

      if ( isset( $menu['classes'] ) && is_array( $menu['classes'] ) && $menu['classes'] )
        $classes[] = implode( $menu['classes'], ' ' );
      if ( isset( $menu['children'] ) && $menu['children'] )
        $classes[] = 'has-children';

      $current = false;
      $menu_uri = ltrim( strtr( $menu['url'], [ site_url() => '' ] ), '/' );

      if ( $menu_uri === ltrim( $uri['path'], '/' ) ) {
        $current = true;
        $stop_current = true;
      } elseif ( isset( $menu['routes'] ) && is_array( $menu['routes'] ) && in_array( route(), $menu['routes'] ) && ! $stop_current ) {
        $current = true;

        if ( strpos( route(), '_paged' ) !== false )
          $menu_uri.= '/page/' . route_vars( 'page' );

        if ( $menu_uri !== ltrim( $uri['path'], '/' ) && ! isset( $menu['children'] ) )
          $current = false;
      }

      if ( $current )
        $classes[] = 'current';

      if ( $classes )
        $output.= ' class="' . implode( $classes, ' ' ) . '"';

      $output.= '>';
      $output.= '<a href="' . $menu['url'] . '">' . $menu['label'] . '</a>';

      if ( isset( $menu['children'] ) && is_array( $menu['children'] ) )
        $output.= "\n" . create_nav_menus_links( $menu['children'], true );

      $output.= '</li>' . "\n";
    }

    $output.= '</ul>' . "\n";

    return $output;
  }

  return false;
}

function spintax( $text ) {
  return preg_replace_callback(
    '/\{(((?>[^\{\{\}\}]+)|(?R))*)\}/x',
    'do_spin',
    $text
  );
}

function do_spintax( $text ) {
  $text = spintax( $text[1] );
  $parts = explode( '|', $text );
  return $parts[array_rand( $parts )];
}
