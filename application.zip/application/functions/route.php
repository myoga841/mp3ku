<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

function route( $value = '' ) {
	global $route;
	if ( $value && $route['name'] === $value ) {
		return true;
	} elseif ( $value && $route['name'] !== $value ) {
		return false;
	} else {
		return $route['name'];
	}
}

function route_vars( $key = '' ) {
	global $route;
	return ( isset( $route['vars'][$key] ) ) ? $route['vars'][$key] : $route['vars'];
}

function query( $var = 'query' ) {
  $var = route_vars( $var );

  if ( $var && ! is_array( $var ) ) {
    $query = strtr( $var, [
      '-' => ' ',
      '_' => ' ',
      '^' => ' ',
      '{' => ' ',
      '}' => ' ',
      '"' => ' ',
      '<' => ' ',
      '>' => ' '
    ] );

    if ( option( 'query_replacements' ) ) {
      $query_replacements_parts = clean_array( explode( "\n", option( 'query_replacements' ) ) );
      foreach ( $query_replacements_parts as $query_replacements_part ) {
        $query_replacements_part_params = explode( '=', $query_replacements_part, 2 );
        $query_replacements[$query_replacements_part_params[0]] = $query_replacements_part_params[1];
      }
    }

    if ( isset( $query_replacements ) )
      $query = strtr( $query, $query_replacements );

    $query = strtr( urldecode( $query ), [ '-' => ' ' ] );
    $query_parts = explode( '/', $query );

    if ( count( $query_parts ) > 1 )
      $query = end( $query_parts );

    $query_parts = explode( '.', $query );

    if ( count( $query_parts ) > 1 ) {
      array_pop( $query_parts );
      $query = implode( $query_parts, '.' );
    }

    return trim( urldecode( ucwords( $query ) ) );
  }

  return;
}

function set_404() {
  global $route;

  header( 'HTTP/1.0 404 Not Found' );

  $route['name']        = '404';
  $route['vars']        = [];
  $route['controllers'] = [ 'main', '404' ];
  $route['template']    = '%theme%/404';

  unset( $route['uri'] );
}
