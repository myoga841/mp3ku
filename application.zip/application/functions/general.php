<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

function site_url() {
  if (
    isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ||
    ! empty( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https' ||
    ! empty( $_SERVER['HTTP_X_FORWARDED_SSL'] ) && $_SERVER['HTTP_X_FORWARDED_SSL'] === 'on'
  ) {
		$https = true;
	} else {
    $https = false;
  }

  if ( ! $https && isset( $_SERVER['HTTP_CF_VISITOR'] ) ) {
    $is_cloudflare = json_decode( $_SERVER['HTTP_CF_VISITOR'] );
    if ( isset( $is_cloudflare->scheme ) && $is_cloudflare->scheme === 'https' )
      $https = true;
  }

	$protocol  = $https ? 'https' : 'http';
	$host      = '://' . HOST;
	$path      = PATH;
	$url       = $protocol . $host . $path;

	return $url;
}

function canonical_url( $query_string = true ) {
  $path         = ( PATH === '' ) ? '/' : PATH;
  $parse_uri    = parse_url( $_SERVER['REQUEST_URI'] );
  $clean_path   = str_replace( PATH, '', $parse_uri['path'] );

  if ( $path === '/' ) {
    $uri = ( $parse_uri['path'] != '/' ) ? '/' . ltrim( $parse_uri['path'], '/' ) : '';
  } else {
    $uri = ( $clean_path !== '/' ) ? '/' . str_replace( PATH . '/', '', $parse_uri['path'] ) : '';
  }

  if ( $query_string && isset( $parse_uri['query'] ) && $parse_uri['query'] )
    $uri.= '?' . $parse_uri['query'];

	return site_url() . $uri;
}

function site_dir( $default = false ) {
  if ( $default ) {
    return DEFAULT_SITE;
  } else {
    return SITE;
  }
}

function clean_uri( $str, $delimiter = '-', $options = [] ) {
  $str = strtr( $str, [
    '&amp;' => '&',
    '&quot;' => '"',
    '&#039;' => "'",
    '&#39;' => "'"
  ] );
  $str = urldecode( html_entity_decode( $str ) );
  $str = mb_convert_encoding( ( string ) $str, 'UTF-8', mb_list_encodings() );
  $defaults = [
		'delimiter'     => $delimiter,
		'limit'         => null,
		'lowercase'     => true,
		'replacements'  => [],
		'transliterate' => false,
	];
	$options = array_merge( $defaults, $options );
  $chars_map = [
		'ÃƒÂ€' => 'A', 'ÃƒÂ' => 'A', 'ÃƒÂ‚' => 'A', 'ÃƒÂƒ' => 'A', 'ÃƒÂ„' => 'A', 'ÃƒÂ…' => 'A', 'ÃƒÂ†' => 'AE', 'ÃƒÂ‡' => 'C',
		'ÃƒÂˆ' => 'E', 'ÃƒÂ‰' => 'E', 'ÃƒÂŠ' => 'E', 'ÃƒÂ‹' => 'E', 'ÃƒÂŒ' => 'I', 'ÃƒÂ' => 'I', 'ÃƒÂŽ' => 'I', 'ÃƒÂ' => 'I',
		'ÃƒÂ' => 'D', 'ÃƒÂ‘' => 'N', 'ÃƒÂ’' => 'O', 'ÃƒÂ“' => 'O', 'ÃƒÂ”' => 'O', 'ÃƒÂ•' => 'O', 'ÃƒÂ–' => 'O', 'Ã…Â' => 'O',
		'ÃƒÂ˜' => 'O', 'ÃƒÂ™' => 'U', 'ÃƒÂš' => 'U', 'ÃƒÂ›' => 'U', 'ÃƒÂœ' => 'U', 'Ã…Â°' => 'U', 'ÃƒÂ' => 'Y', 'ÃƒÂž' => 'TH',
		'ÃƒÂŸ' => 'ss',
		'Ãƒ ' => 'a', 'ÃƒÂ¡' => 'a', 'ÃƒÂ¢' => 'a', 'ÃƒÂ£' => 'a', 'ÃƒÂ¤' => 'a', 'ÃƒÂ¥' => 'a', 'ÃƒÂ¦' => 'ae', 'ÃƒÂ§' => 'c',
		'ÃƒÂ¨' => 'e', 'ÃƒÂ©' => 'e', 'ÃƒÂª' => 'e', 'ÃƒÂ«' => 'e', 'ÃƒÂ¬' => 'i', 'ÃƒÂ­' => 'i', 'ÃƒÂ®' => 'i', 'ÃƒÂ¯' => 'i',
		'ÃƒÂ°' => 'd', 'ÃƒÂ±' => 'n', 'ÃƒÂ²' => 'o', 'ÃƒÂ³' => 'o', 'ÃƒÂ´' => 'o', 'ÃƒÂµ' => 'o', 'ÃƒÂ¶' => 'o', 'Ã…Â‘' => 'o',
		'ÃƒÂ¸' => 'o', 'ÃƒÂ¹' => 'u', 'ÃƒÂº' => 'u', 'ÃƒÂ»' => 'u', 'ÃƒÂ¼' => 'u', 'Ã…Â±' => 'u', 'ÃƒÂ½' => 'y', 'ÃƒÂ¾' => 'th',
		'ÃƒÂ¿' => 'y',
		'Ã‚Â©' => '(c)',
		'ÃŽÂ‘' => 'A', 'ÃŽÂ’' => 'B', 'ÃŽÂ“' => 'G', 'ÃŽÂ”' => 'D', 'ÃŽÂ•' => 'E', 'ÃŽÂ–' => 'Z', 'ÃŽÂ—' => 'H', 'ÃŽÂ˜' => '8',
		'ÃŽÂ™' => 'I', 'ÃŽÂš' => 'K', 'ÃŽÂ›' => 'L', 'ÃŽÂœ' => 'M', 'ÃŽÂ' => 'N', 'ÃŽÂž' => '3', 'ÃŽÂŸ' => 'O', 'ÃŽ ' => 'P',
		'ÃŽÂ¡' => 'R', 'ÃŽÂ£' => 'S', 'ÃŽÂ¤' => 'T', 'ÃŽÂ¥' => 'Y', 'ÃŽÂ¦' => 'F', 'ÃŽÂ§' => 'X', 'ÃŽÂ¨' => 'PS', 'ÃŽÂ©' => 'W',
		'ÃŽÂ†' => 'A', 'ÃŽÂˆ' => 'E', 'ÃŽÂŠ' => 'I', 'ÃŽÂŒ' => 'O', 'ÃŽÂŽ' => 'Y', 'ÃŽÂ‰' => 'H', 'ÃŽÂ' => 'W', 'ÃŽÂª' => 'I',
		'ÃŽÂ«' => 'Y',
		'ÃŽÂ±' => 'a', 'ÃŽÂ²' => 'b', 'ÃŽÂ³' => 'g', 'ÃŽÂ´' => 'd', 'ÃŽÂµ' => 'e', 'ÃŽÂ¶' => 'z', 'ÃŽÂ·' => 'h', 'ÃŽÂ¸' => '8',
		'ÃŽÂ¹' => 'i', 'ÃŽÂº' => 'k', 'ÃŽÂ»' => 'l', 'ÃŽÂ¼' => 'm', 'ÃŽÂ½' => 'n', 'ÃŽÂ¾' => '3', 'ÃŽÂ¿' => 'o', 'ÃÂ€' => 'p',
		'ÃÂ' => 'r', 'ÃÂƒ' => 's', 'ÃÂ„' => 't', 'ÃÂ…' => 'y', 'ÃÂ†' => 'f', 'ÃÂ‡' => 'x', 'ÃÂˆ' => 'ps', 'ÃÂ‰' => 'w',
		'ÃŽÂ¬' => 'a', 'ÃŽÂ­' => 'e', 'ÃŽÂ¯' => 'i', 'ÃÂŒ' => 'o', 'ÃÂ' => 'y', 'ÃŽÂ®' => 'h', 'ÃÂŽ' => 'w', 'ÃÂ‚' => 's',
		'ÃÂŠ' => 'i', 'ÃŽÂ°' => 'y', 'ÃÂ‹' => 'y', 'ÃŽÂ' => 'i',
		'Ã…Âž' => 'S', 'Ã„Â°' => 'I', 'ÃƒÂ‡' => 'C', 'ÃƒÂœ' => 'U', 'ÃƒÂ–' => 'O', 'Ã„Âž' => 'G',
		'Ã…ÂŸ' => 's', 'Ã„Â±' => 'i', 'ÃƒÂ§' => 'c', 'ÃƒÂ¼' => 'u', 'ÃƒÂ¶' => 'o', 'Ã„ÂŸ' => 'g',
		'ÃÂ' => 'A', 'ÃÂ‘' => 'B', 'ÃÂ’' => 'V', 'ÃÂ“' => 'G', 'ÃÂ”' => 'D', 'ÃÂ•' => 'E', 'ÃÂ' => 'Yo', 'ÃÂ–' => 'Zh',
		'ÃÂ—' => 'Z', 'ÃÂ˜' => 'I', 'ÃÂ™' => 'J', 'ÃÂš' => 'K', 'ÃÂ›' => 'L', 'ÃÂœ' => 'M', 'ÃÂ' => 'N', 'ÃÂž' => 'O',
		'ÃÂŸ' => 'P', 'Ã ' => 'R', 'ÃÂ¡' => 'S', 'ÃÂ¢' => 'T', 'ÃÂ£' => 'U', 'ÃÂ¤' => 'F', 'ÃÂ¥' => 'H', 'ÃÂ¦' => 'C',
		'ÃÂ§' => 'Ch', 'ÃÂ¨' => 'Sh', 'ÃÂ©' => 'Sh', 'ÃÂª' => '', 'ÃÂ«' => 'Y', 'ÃÂ¬' => '', 'ÃÂ­' => 'E', 'ÃÂ®' => 'Yu',
		'ÃÂ¯' => 'Ya',
		'ÃÂ°' => 'a', 'ÃÂ±' => 'b', 'ÃÂ²' => 'v', 'ÃÂ³' => 'g', 'ÃÂ´' => 'd', 'ÃÂµ' => 'e', 'Ã‘Â‘' => 'yo', 'ÃÂ¶' => 'zh',
		'ÃÂ·' => 'z', 'ÃÂ¸' => 'i', 'ÃÂ¹' => 'j', 'ÃÂº' => 'k', 'ÃÂ»' => 'l', 'ÃÂ¼' => 'm', 'ÃÂ½' => 'n', 'ÃÂ¾' => 'o',
		'ÃÂ¿' => 'p', 'Ã‘Â€' => 'r', 'Ã‘Â' => 's', 'Ã‘Â‚' => 't', 'Ã‘Âƒ' => 'u', 'Ã‘Â„' => 'f', 'Ã‘Â…' => 'h', 'Ã‘Â†' => 'c',
		'Ã‘Â‡' => 'ch', 'Ã‘Âˆ' => 'sh', 'Ã‘Â‰' => 'sh', 'Ã‘ÂŠ' => '', 'Ã‘Â‹' => 'y', 'Ã‘ÂŒ' => '', 'Ã‘Â' => 'e', 'Ã‘ÂŽ' => 'yu',
		'Ã‘Â' => 'ya',
		'ÃÂ„' => 'Ye', 'ÃÂ†' => 'I', 'ÃÂ‡' => 'Yi', 'Ã’Â' => 'G',
		'Ã‘Â”' => 'ye', 'Ã‘Â–' => 'i', 'Ã‘Â—' => 'yi', 'Ã’Â‘' => 'g',
		'Ã„ÂŒ' => 'C', 'Ã„ÂŽ' => 'D', 'Ã„Âš' => 'E', 'Ã…Â‡' => 'N', 'Ã…Â˜' => 'R', 'Ã… ' => 'S', 'Ã…Â¤' => 'T', 'Ã…Â®' => 'U',
		'Ã…Â½' => 'Z',
		'Ã„Â' => 'c', 'Ã„Â' => 'd', 'Ã„Â›' => 'e', 'Ã…Âˆ' => 'n', 'Ã…Â™' => 'r', 'Ã…Â¡' => 's', 'Ã…Â¥' => 't', 'Ã…Â¯' => 'u',
		'Ã…Â¾' => 'z',
		'Ã„Â„' => 'A', 'Ã„Â†' => 'C', 'Ã„Â˜' => 'e', 'Ã…Â' => 'L', 'Ã…Âƒ' => 'N', 'ÃƒÂ“' => 'o', 'Ã…Âš' => 'S', 'Ã…Â¹' => 'Z',
		'Ã…Â»' => 'Z',
		'Ã„Â…' => 'a', 'Ã„Â‡' => 'c', 'Ã„Â™' => 'e', 'Ã…Â‚' => 'l', 'Ã…Â„' => 'n', 'ÃƒÂ³' => 'o', 'Ã…Â›' => 's', 'Ã…Âº' => 'z',
		'Ã…Â¼' => 'z',
		'Ã„Â€' => 'A', 'Ã„ÂŒ' => 'C', 'Ã„Â’' => 'E', 'Ã„Â¢' => 'G', 'Ã„Âª' => 'i', 'Ã„Â¶' => 'k', 'Ã„Â»' => 'L', 'Ã…Â…' => 'N',
		'Ã… ' => 'S', 'Ã…Âª' => 'u', 'Ã…Â½' => 'Z',
		'Ã„Â' => 'a', 'Ã„Â' => 'c', 'Ã„Â“' => 'e', 'Ã„Â£' => 'g', 'Ã„Â«' => 'i', 'Ã„Â·' => 'k', 'Ã„Â¼' => 'l', 'Ã…Â†' => 'n',
		'Ã…Â¡' => 's', 'Ã…Â«' => 'u', 'Ã…Â¾' => 'z'
	];
  $str = preg_replace( array_keys( $options['replacements'] ), $options['replacements'], $str );
  $str = ( $options['transliterate'] ) ? str_replace( array_keys( $chars_map ), $chars_map, $str ) : $str;
	$str = preg_replace( '/[^\p{L}\p{Nd}]+/u', $options['delimiter'], $str );
	$str = preg_replace( '/(' . preg_quote( $options['delimiter'], '/') . '){2,}/', '$1', $str );
	$str = substr( $str, 0, ( $options['limit'] ? $options['limit'] : strlen( $str ) ) );
	$str = trim( $str, $options['delimiter'] );
  $str = $options['lowercase'] ? strtolower( $str ) : $str;

	return $str;
}

function uri_has_extension( $uri ) {
	$exp_uri       = explode( '/', $uri );
	$last_item     = end( $exp_uri );
	$exp_last_item = explode( '.', $last_item, 2 );

  return ( count( $exp_last_item ) > 1 ) ? end( $exp_last_item ) : false;
}

function redirect( $url = '', $options = [] ) {
  $defaults = [
    'permanent' => false,
    'method'    => '',
    'timeout'   => 5
  ];
  $options = array_merge( $defaults, $options );

  if ( $options['method'] === 'refresh' ) {
    header( 'Refresh: ' . $options['timeout'] . '; url=' . $url );
  } else {
    if ( $options['permanent'] )
      header( 'HTTP/1.1 301 Moved Permanently' );

    header( 'Location: ' . $url );
    die();
  }
}

function error( $message = '', $title = 'Error!', $align = 'center' ) {
  $html = '<!DOCTYPE html><html><head>';
  $html.= '<meta charset="utf-8" />';
  $html.= '<meta http-equiv="X-UA-Compatible" content="IE=edge" />';
  $html.= '<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport" />';
  $html.= '<title>' . $title . '</title>';
  $html.= '<style type="text/css">';
  $html.= 'body { padding: 0; margin: 0; overflow-y: scroll; text-align: ' . $align . '; font: normal 14px/20px -apple-system,BlinkMacSystemFont,Helvetica,Arial,sans-serif; color: #444; }';
  $html.= 'div { line-height: 26px; padding: 22px 30px 23px 30px; background: #ffd4d4; color: #e64b4b; }';
  $html.= 'strong { font-weight: 600; }';
  $html.= 'p { margin: 0; }';
  $html.= '</style>';
  $html.= '</head><body><div>' . $message . '</div></body></html>';

  die( $html );
}

function debug( $data, $die = true ) {
  echo '<pre>';
  print_r( $data );
  echo '</pre>';

  if ( $die )
    die();
}

function clean_array( $data ) {
  return array_values( array_filter( array_map( 'trim', $data ), 'strlen' ) );
}

function base64__encode( $str ) {
	return rtrim( strtr( base64_encode( $str ), '+/', '-_' ), '=' );
}

function base64__decode( $str ) {
	return base64_decode( str_pad( strtr( $str, '-_', '+/' ), strlen( $str ) % 4, '=', STR_PAD_RIGHT ) );
}

function multi_explode( $delimiters, $string ) {
	$ready   = str_replace( $delimiters, $delimiters[0], $string );
	$launch  = explode( $delimiters[0], $ready );

  return $launch;
}

function limit_word( $string, $word_limit ) {
	$words = explode( ' ', $string );
	return implode( ' ', array_slice( $words, 0, $word_limit ) );
}

function multi_sort( $args ) {
  $data = array_shift( $args );

  foreach ( $args as $index => $field ) {
    if ( is_string( $field ) ) {
      $temp = [];

      foreach ( $data as $key => $row )
        $temp[$key] = $row[$field];

      $args[$index] = $temp;
    }
  }

  $args[] = &$data;

  call_user_func_array( 'array_multisort', $args );

  return array_pop( $args );
}

function is_ajax() {
  if ( isset( $_SERVER['HTTP_X_REQUESTED_WITH'] ) && strtolower( $_SERVER['HTTP_X_REQUESTED_WITH'] ) === 'xmlhttprequest' ) {
    return true;
  } else {
    return false;
  }
}

function is_bot() {
  return ( isset( $_SERVER['HTTP_USER_AGENT'] ) && preg_match( '/bot|crawl|slurp|spider|mediapartners/i', $_SERVER['HTTP_USER_AGENT'] ) );
}

function is_json( $json ) {
  if ( is_numeric( $json ) )
    return false;

  json_decode( $json );

  return ( json_last_error() === JSON_ERROR_NONE );
}
