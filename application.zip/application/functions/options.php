<?php

if ( ! defined( 'MC' ) )
  die( 'No direct script access allowed!' );

/*----------------------------------------------------------------------------*/

function option( $key, $default = '', $type = 'options' ) {
  global $config;

  $option = false;

  if ( isset( $config[$type][$key] ) && ! is_bool( $config[$type][$key] ) && $config[$type][$key] ) {
    $option = $config[$type][$key];
  } elseif ( isset( $config[$type][$key] ) ) {
    $option = $config[$type][$key];
  } elseif ( $default ) {
    $option = $default;
  }

  if ( strpos( $option, 'file:' ) !== false ) {
    $file = strtr( $option, [
      'file:' => '',
      '%base%' => BASE,
      '%default_site_dir%' => DEFAULT_SITE,
      '%site_dir%' => SITE
    ] );
    if ( file_exists( $file ) ) {
      $option = file_get_contents( $file );
    } else {
      $option = false;
    }
  }

  if ( $option && ! is_numeric( $option ) && is_json( $option ) ) {
    $option = json_decode( $option, true );
  } else {
    $option = strtr( $option, [
      '%site_url%' => site_url()
    ] );
  }

  return $option;
}

function theme_option( $key, $default = '' ) {
  return option( $key, $default, 'theme_options' );
}
